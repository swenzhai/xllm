# T5 QKV 规范化 case 总表说明

本目录中的 JSON、CSV 为从冻结执行证据派生的统计材料，不是原始执行日志，也不代替七件交付中的工作簿或原始 stdout/stderr。

本次输入是当前独立包与 `development_evidence/20261029_ab70af7/raw/reports/final_176_01/`。被测实现提交为 `ab70af7891455b36c7aaac6344f0f2207afcc068`。所有证据路径以 `T5QKV_wsp` 为根目录；路径后 `#` 表示 RFC 6901 JSON Pointer，数组下标从 0 开始。

## 产物与字段

| 文件 | 内容 |
|---|---|
| `case_ledger.json` | 唯一规范化数据源；`.cases` 恰好 35 行。另含 summary、原始环境、字段来源和限制。 |
| `CASE_INDEX.csv` | 同样 35 行的扁平表，保留全部 shape、五轮性能值、内存字节数、回收和证据引用，供完整统计 sheet 使用。 |
| `evidence_index.json` | 原始文件路径、长度与 SHA-256；实际命令及返回码；源码冻结检查；每个 case 的 JSON Pointer。 |
| `EVIDENCE_FILES.csv` | 文件级证据索引，原始文件不改名、不改写。 |
| `official_case_ids.csv` | 从官方 case.json 直接抽取的 35 个唯一 ID，用于对账。 |
| `ledger_validation.json` | 本地派生数据的复核结果，不是正式验收通过声明。 |
| `build_case_ledger.py` | 只读原始材料、使用 Python 标准库生成以上表格；没有导入 torch 或运行 NPU。 |

CSV 使用 UTF-8 BOM；复杂字段为 JSON 文本；缺失和不适用的数值为空，不用 0 冒充未测数据。JSON 中未知量为 `null`，不适用对象明确 `applicable=false,status=not_applicable,measured=false`。

主要 JSON 字段：

- `case_id`、`kind`、`dtype`、`input_desc`、`output_desc`、`attributes`：来自原始 `case.json`；`parameters` 为从 pastKey shape 提取的 B/H/L/D；全部实际输入和输出 shape 均保留。
- `audit`：仅指官方 ID 是否包含 `_audit_`，共 9 项，不推断额外审计结果。`kind` 原样保留，例如名称含 boundary 的 case，其生成器 kind 仍可为 random。
- `official_case_sha256`：来自 `coverage_requirements.json`，并对每条 case 的排序紧凑 JSON 独立重算；这是 case 定义摘要，不是输入张量摘要。
- `precision`：官方 `public_accuracy.json` 中的 run 结果；三个输出的元素数与 `bit_mismatches` 原样保留。`precision.entries.run/run_direct` 来自 `extended.json` 的 public 分组，包含各路径位差、输入不变与输出存储指针。元素数按官方 shape 独立核对。
- `performance`：仅官方 `performance=true` 的 10 项适用。数据来自 `performance.json` 的 `results.custom`，五轮 wall/device-event 均值全部保留，并用中位数函数重新计算中位数；阈值来自 `performance_targets.json`，与 `performance_check.json` 独立对账。协议为预热 50 次、5 轮、每轮 200 次，单位 μs。设备事件时间包含提交间隙，不命名为纯内核时间。
- `performance.current_over_absolute_limit`：当前中位数除以绝对 μs 上限，仅用于表达余量，**不是模板中的当前/实测标杆比值**。`measured_baseline_us` 与 `current_over_measured_baseline` 为空，因为最终记录没有测量基线。
- `memory`：仅相同 10 项适用；来自 `extended.json` 的 memory 分组。每项有 workspace、output_bytes、allocated/active 峰值增量、limit、释放前后 allocated/active 与回收差值。输出字节数按所有输出元素总数 × 2 独立重算；限制为输出字节数 + 16384。测量器先预热 3 次，再测量 1 次；这是框架张量分配器字节数，不是整卡 HBM。
- `repeated_recovery`：来自 extended recovery 分组。只有 case018 有 run/run_direct 各 20 次重复回收记录；另外 34 项明确没有该 case 的重复回收记录。不得将这一组重复回收结果写成每个 case 均重复 20 次。
- `implementation_commit`、构建产物与环境：来自 `runtime_identity.json`、`pretest_manifest.json`、`source_manifest.json`、`performance.json` 和 `raw/env/logs/environment.json`。本地逐字节检查了 26 个归档源码文件，共同的 25 个 pretest 源码摘要未变化。新增 `tests/cache_boundary.py` 仅在最终 manifest 中出现，其 8 项结果单列为补充证据。
- 每行的 `evidence` / CSV `*_evidence` 指向准确 JSON 数组元素；对应原始 stdout/stderr 也逐行给出路径。文件大小与 SHA-256 在文件索引中查找。JSON 执行结果和原始 `.log` 均保持原字节。

## 对账结果

官方 case 35 项，精度 35/35；扩展公开双路径 70/70。性能与内存各 10 项适用并在实际开发环境通过已执行检查，25 项按任务书 §3.5、README 与 case.json 标记 N/A。性能保留 50 个 wall 轮均值与 50 个 device-event 轮均值。扩展总计 206 条记录全部通过，额外输入、非法输入等不增加官方 case 行数。

生成器校验 ID 集合、无重复、每 case 两路径、输出元素数、零位差、五轮数量与中位数、协议、绝对性能阈值、内存上限和回收、源码及产物指纹一致性。独立指针对账及官方 CSV 审计的输出保存在同目录。此处通过仅代表派生数据与指定冻结文件一致，不代表正式环境或整个任务已获验收。

## 明确保留的证据边界

1. 当前任务书 §3.3 写同机基线比值，并要求候选基线实测；README、`performance_targets.json`（`absolute-wall-us-reviewed-v3`）及官方执行脚本采用绝对 μs 阈值。最终证据只包含 custom。因此性能表只可说“绝对阈值检查通过”，不能填写同机实测标杆或加速比，也不能用任务书参考值冒充实测值。
2. `SHA256SUMS.txt` 最后一项命名为不存在的 `题目3-T5QKV拆分与缓存追加算子任务书.md`，期望摘要 `f494347ab477b13cbf9f817df2562e07701e941e4cb616fef3fcf1cba0186144`。现有 `T5QKV拆分与缓存追加算子任务书.md` 摘要为 `e65bf0cc08fcb170bf9b15caac0922fa3cde539f4a58c23722c15fe3bdb7ca57`。其余 10 项匹配。索引保留此差异，未更改任务书或哈希清单。
3. `formal_environment_verified=false`。报告设备为 Ascend910_9382，CANN 安装版本 9.1.0，Python 3.12.13，torch 2.10.0+cpu；单独环境记录提供 torch_npu git `5dd8ef3f9b375b5ae4a83538d5785754148c3302`。但要求的完整 OS/驱动/设备可见性未由这些 case 报告证实，报告内驱动为 unknown，环境记录有两个可见逻辑设备、实际测试选 npu:0。不可据绝对阈值检查声称正式环境全匹配。
4. 当前冻结包没有每项输入/输出二进制或输入张量哈希。可由固定种子生成器重建；case 定义哈希不能替代输入数据哈希。
5. 原始本地 tar 的 SHA-256 为 `cc9d89474fdefe205035b26cebdc4d2174f37692a2cb31a0cf92e06e405dcfaa`。本任务独立复算本地归档和内部源码；没有把未经本任务读取的服务器传输校验自动记为通过。
6. 报告所需现场截图应由主交付流程另行确认；本表没有生成或补造截图。正式提交就绪与正式验收通过需要主交付流程分别判断。

复现本地表格生成：

```bash
python3 build_case_ledger.py
python3 /Users/swen/.codex/skills/cann-delivery/scripts/audit_case_ids.py official_case_ids.csv:case_id CASE_INDEX.csv:case_id
```
