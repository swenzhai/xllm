# 交付证据索引

本ZIP为本地派生证据包，不是服务器原始tar。所有 raw/ 和原始任务包文件按工作区相对路径存放并逐字节复制。根目录 ledger/CSV/audit 为派生统计，不是程序stdout。

原始归档 evidence_ab70af7.tar.gz SHA256 为 cc9d89474fdefe205035b26cebdc4d2174f37692a2cb31a0cf92e06e405dcfaa，仍保存在工作区 development_evidence/20261029_ab70af7。该tar的54个成员已与解压副本逐字节核对。这个ZIP不嵌套原tar。

按任务书4保留被测开发环境的 .run 安装包（project/build_final_176/custom_opp_ubuntu_aarch64.run），指定环境需重新构建。排除产品源码树及direct/framework SO，保留测试源码、全部最终原始日志/JSON、实际命令、源码和加载库hash。产品源码请从 https://github.com/swenzhai/xllm/tree/ab70af7891455b36c7aaac6344f0f2207afcc068/xllm/core/kernels/npu/xllm_ops/t5_split_qkv_append_cache 获取。EVIDENCE_FILES/source_manifest 中 raw/project 非tests源码的路径指向冻结原件；其代码由该提交提供，排除映射见 EXCLUDED_SOURCE_AND_BINARIES.json。

原任务包保留原始文件名、内容及SHA256SUMS异常。截图尚缺；原日志不含本地补造的PASS/汇总。未归档逐输入/输出二进制，重建规则为原始固定种子生成器、case定义及验证器。完整源码、产物和服务器原始tar在开发归档区可追溯。

校验：解压后运行 sha256sum -c SHA256SUMS.txt。SHA256SUMS.txt覆盖除自身外的全部成员。
