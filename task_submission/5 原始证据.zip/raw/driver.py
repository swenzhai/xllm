from pathlib import Path
import subprocess,json,sys
r=Path('/workspace/t5qkv-byte-balanced-pair-20261114-01');n='c37_byte_balanced_pair';py='/workspace/t5qkv-dev-20261029/env/venv/bin/python'
plan=[[py,str(r/'runner/build.py'),'--prepared-root',str(r),'--candidate',n],[py,str(r/'runner/run_functional.py'),'--prepared-root',str(r),'--report-dir',str(r/'functional_full_01'),'--candidates',n,'--full'],[py,str(r/'runner/run_matrix.py'),'--prepared-root',str(r),'--report-dir',str(r/'screen_01'),'--candidates',n,'--phase','screen','--post-identity']]
s={'source_revision':'8cf6bd539069e32d79b6f73d2629c8d422cc6ce7','bundle_sha256':'d6afc2ab21fcd9d925fbd979aacd620492663ee1a21030435319c4216090ae7d','status':'running','plan':plan,'stages':[],'confirmation_eligible_candidates':[n]}
def save():(r/'driver_plan.json').write_text(json.dumps(s,indent=2)+'\n')
save()
for i,cmd in enumerate(plan):
 with (r/f'driver_stage_{i}.log').open('xb') as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
 s['stages'].append({'index':i,'exit_code':rc});save()
 if rc:s.update(status='failed_stage_'+str(i));save();sys.exit(rc)
full=json.loads((r/'functional_full_01/summary.json').read_text());screen=json.loads((r/'screen_01/summary.json').read_text());assert full['status']=='passed' and len(full['records'])==22 and full['source_and_artifacts_unchanged'];assert screen['status']=='passed' and len(screen['records'])==6 and screen['source_and_artifacts_unchanged']
cmd=[py,str(r/'runner/run_matrix.py'),'--prepared-root',str(r),'--report-dir',str(r/'confirm_01'),'--candidates',n,'--phase','confirm','--batches','10','--post-identity'];s['plan'].append(cmd);s.update(status='running_confirm_01');save()
with (r/'confirm_driver.log').open('xb') as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
s['stages'].append({'label':'confirm_01','exit_code':rc});q=json.loads((r/'confirm_01/summary.json').read_text());s.update(status='full_screen_confirm_passed_not_promoted' if rc==0 and q['status']=='passed' and q['source_and_artifacts_unchanged'] else 'failed_confirm_01');save();sys.exit(rc)
