# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Run original executors for real UI capture; retain every emitted byte."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/t5qkv-byte-balanced-pair-20261114-01')
sys.path.insert(0, str(ROOT / 'runner'))
from evidence import _environment, _read, _write
from run_matrix import _freeze_files, _snapshot

mode = sys.argv[1]
assert mode in ('accuracy', 'performance', 'memory')
out = ROOT / 'visible_validation_01' / mode
out.mkdir(parents=True, exist_ok=False)
files = _freeze_files(ROOT, ['c37_byte_balanced_pair'], ROOT / 'official_task_package')
before = _snapshot(files)
_write(out / 'pretest_manifest.json', before)
project = ROOT / 'c37_byte_balanced_pair/project'
package = ROOT / 'official_task_package'
script = package / ('benchmark.py' if mode == 'performance' else 'verify.py')
extra = []
if mode == 'memory':
    script = project / 'tests/acceptance.py'
    extra = ['--package-dir', str(package), '--groups', 'memory']
command = [sys.executable, str(script), '--solution-file', str(project / 'solution.py'),
           '--report', str(out / 'report.json'), *extra]
if mode == 'performance':
    command = [sys.executable, str(ROOT / 'runner/identity/after_benchmark.py'),
               '--script', str(script), '--identity', str(out / 'runtime_identity.json'),
               '--expected-prefix', str(ROOT / 'c37_byte_balanced_pair/install/vendors/t5qkv'),
               '--', *command[2:]]
env = _environment(ROOT, 'c37_byte_balanced_pair', 'default')
_write(out / 'command.json', {'command': command, 'allocator_environment': env.get('PYTORCH_NPU_ALLOC_CONF')})
print('Host: d404fbb2c45f / Ascend910_9382 / logical0 / physical6', flush=True)
print('Default allocator: PYTORCH_NPU_ALLOC_CONF unset', flush=True)
print('Executing:', ' '.join(command), flush=True)
with (out / 'executor.log').open('xb') as log:
    rc = subprocess.run(command, cwd=package, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
report = _read(out / 'report.json')
after = _snapshot(files)
_write(out / 'posttest_manifest.json', after)
assert before == after
assert rc == 0 and report['status'] == 'passed' and report['npu_executed']
rows = report.get('cases', report.get('records', []))
if mode == 'performance':
    for row in report['performance_checks']['checks']:
        print(row['case_name'], row['wall_us_median'], 'us <=', row['max_wall_us'], row['status'], flush=True)
elif mode == 'memory':
    for row in rows:
        d = row['details']
        print(row['case_name'], 'peak_active_delta=', d['peak_active_delta'], 'limit=', d['limit_bytes'], row['status'], flush=True)
else:
    for row in rows[-9:]:
        print(row['case_name'], row['status'], 'mismatches=', sum(o['bit_mismatches'] for o in row['outputs']), flush=True)
print('Original executor:', report['status'], len(rows), 'records; source/artifacts unchanged', flush=True)
print('Raw log SHA256:', hashlib.sha256((out / 'executor.log').read_bytes()).hexdigest(), flush=True)
