# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Canary metadata decoder. Query is intentionally modified; no acceptance claim."""
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
import torch
import torch_npu
ROOT=Path('/workspace/t5qkv-dev-20261029')
sys.path.insert(0,str(ROOT/'public'))
import generate_data
import golden
import verify


def _main() -> None:
    torch.npu.set_device(0)
    spec=importlib.util.spec_from_file_location('probe_solution',ROOT/'project_controlled_modes_02/solution.py')
    solution=importlib.util.module_from_spec(spec);spec.loader.exec_module(solution)
    extension=solution._extension()
    report={'scope':'device_metadata_canary_query_intentionally_modified_not_acceptance','records':[]}
    target=ROOT/'reports/hint_probe_01.json'
    for case in json.loads((ROOT/'public/case.json').read_text()):
        if not any(x in case['case_name'] for x in ['_007_','_017_']):continue
        arrays=generate_data.generate(case)
        arrays[0].view(np.uint16).reshape(-1)[:]=np.arange(arrays[0].size,dtype=np.uint16)
        inputs=verify.device_inputs(case,arrays,'npu:0')
        expected=golden.calculate(arrays,{'headNum':16,'headDim':64})
        outputs=(torch.empty((16,16,1,64),device='npu:0',dtype=inputs[0].dtype),
                 torch.empty((16,16,2049,64),device='npu:0',dtype=inputs[0].dtype),
                 torch.empty((16,16,2049,64),device='npu:0',dtype=inputs[0].dtype))
        for mode in [3,0,1,2,3,4,5,6,3]:
            extension.run_out_diagnostic(inputs,outputs,16,64,mode)
            torch.npu.synchronize()
            q=verify.cpu_array(outputs[0]).view(np.uint16).reshape(-1)
            assert all(int(x) in [0,1] for x in q[3:259])
            deltas=[sum(int(q[3+64*index+bit])<<bit for bit in range(64)) for index in range(4)]
            for actual,wanted in zip(outputs[1:],expected[1:]):
                assert np.array_equal(verify.cpu_array(actual).view(np.uint16),wanted.view(np.uint16))
            assert np.array_equal(q[259:],expected[0].view(np.uint16).reshape(-1)[259:])
            row={'case_name':case['case_name'],'requested_mode':mode,'observed_key_rows':int(q[0]),
                 'observed_cache_flags':int(q[1]),'observed_tile':int(q[2]),
                 'hint_address_deltas':dict(zip(['past_key','past_value','key','value'],[hex(x) for x in deltas])),
                 'kv_bit_exact':True,'query_modified_for_canary':True}
            report['records'].append(row);target.write_text(json.dumps(report,indent=2));print(json.dumps(row),flush=True)
            assert int(q[1]) == (mode<<8)|1
        for actual,wanted in zip(inputs,arrays):assert np.array_equal(verify.cpu_array(actual).view(np.uint16),wanted.view(np.uint16))
        del inputs,outputs
    report['status']='canary_completed';target.write_text(json.dumps(report,indent=2))


if __name__=='__main__':_main()
