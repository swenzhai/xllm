# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Diagnostic allocating mode-3 entry; not a submitted acceptance entry."""
import importlib.util
from pathlib import Path
import torch
ROOT=Path('/workspace/t5qkv-dev-20261029')
_spec=importlib.util.spec_from_file_location('cache_mode_solution',ROOT/'project_controlled_modes_01/solution.py')
_impl=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_impl)


def run(inputs:list,attributes:dict) -> tuple:
    heads,dim=attributes['headNum'],attributes['headDim']
    b,h,l,d=inputs[1].shape
    outputs=(torch.empty((b,h,1,d),device=inputs[0].device,dtype=inputs[0].dtype),
             torch.empty((b,h,l+1,d),device=inputs[0].device,dtype=inputs[0].dtype),
             torch.empty((b,h,l+1,d),device=inputs[0].device,dtype=inputs[0].dtype))
    _impl._extension().run_out_diagnostic(inputs,outputs,heads,dim,3)
    return outputs
