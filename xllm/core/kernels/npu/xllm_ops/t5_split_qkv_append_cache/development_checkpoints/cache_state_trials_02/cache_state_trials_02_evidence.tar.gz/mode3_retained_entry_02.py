# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Diagnostic retained-output mode-3 entry; violates fresh-output contract."""
import importlib.util
from pathlib import Path
import torch
ROOT=Path('/workspace/t5qkv-dev-20261029')
_spec=importlib.util.spec_from_file_location('cache_mode_solution',ROOT/'project_controlled_modes_02/solution.py')
_impl=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_impl)


_HELD = None
_TRACE = []

def run(inputs:list,attributes:dict) -> tuple:
    global _HELD
    heads,dim=attributes['headNum'],attributes['headDim']
    b,h,l,d=inputs[1].shape
    if _HELD is not None and inputs[1].numel() == 33554432:
        outputs = _HELD
    else:
        outputs=(torch.empty((b,h,1,d),device=inputs[0].device,dtype=inputs[0].dtype),
             torch.empty((b,h,l+1,d),device=inputs[0].device,dtype=inputs[0].dtype),
             torch.empty((b,h,l+1,d),device=inputs[0].device,dtype=inputs[0].dtype))
    if inputs[1].numel() == 33554432:
        if _HELD is None:
            _HELD = outputs
        outputs = _HELD
    else:
        _HELD = None
    _impl._extension().run_out_diagnostic(inputs,outputs,heads,dim,3)
    return outputs
