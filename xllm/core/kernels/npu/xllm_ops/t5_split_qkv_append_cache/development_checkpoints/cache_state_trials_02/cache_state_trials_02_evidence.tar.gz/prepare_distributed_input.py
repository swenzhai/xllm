# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Distribute bounded normal-read admission over both immutable history inputs."""
from pathlib import Path
import shutil,tarfile
r=Path('/workspace/t5qkv-dev-20261029');b=r/'project_distributed_input_01';b.mkdir(exist_ok=False)
with tarfile.open(r/'baseline_sources.tar') as t:
 for m in t:
  if m.isfile() and not m.name.startswith(('docs/','development_checkpoints/')):
   p=b/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
shutil.copy2(r/'project/.clang-format',b/'.clang-format')
p=b/'common/t5_split_qkv_append_cache_tiling.h';s=p.read_text().replace('  uint32_t bypass_value_cache;','  uint32_t bypass_value_cache;\n  uint32_t cache_input_period;').replace('== 13 * sizeof(uint32_t)','== 14 * sizeof(uint32_t)')
s=s.replace('  result.bypass_value_cache = policy.bypass_value ? 1 : 0;','''  result.bypass_value_cache = policy.bypass_value ? 1 : 0;
  const uint64_t n = uint64_t{result.batch} * result.head_num * result.head_dim;
  const uint64_t output_base = 4 * n * (result.past_length + 3);
  if (policy.bypass_value && output_base <= kL2BudgetBytes && result.past_length != 0) {
    const uint64_t input_row_bytes = uint64_t{2} * result.past_length * result.head_dim;
    const uint64_t allowed_rows = (kL2BudgetBytes - output_base) / input_row_bytes;
    const uint64_t rows = uint64_t{2} * result.batch * result.head_num;
    if (allowed_rows != 0) {
      result.cache_input_period = static_cast<uint32_t>((rows + allowed_rows - 1) / allowed_rows);
    }
  }''');p.write_text(s)
p=b/'op_kernel/t5_split_qkv_append_cache_kernel.h';s=p.read_text()
s=s.replace('      past_value_.SetGlobalBuffer(','''      past_key_bypass_.SetGlobalBuffer(
          reinterpret_cast<__gm__ uint16_t*>(past_key), query_elements * tiling.past_length);
      past_value_bypass_.SetGlobalBuffer(
          reinterpret_cast<__gm__ uint16_t*>(past_value), query_elements * tiling.past_length);
      past_key_bypass_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);
      past_value_bypass_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);
      past_value_.SetGlobalBuffer(''',1)
s=s.replace('    key_bypass_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);','''    retain_outputs_ = tiling.bypass_value_cache != 0 &&
        uint64_t{4} * query_elements * (tiling.past_length + 3) <= kL2BudgetBytes;
    if (!retain_outputs_) {
      key_bypass_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);
    }''',1)
s=s.replace('    if (tiling.bypass_value_cache != 0) {','    if (tiling.bypass_value_cache != 0 && !retain_outputs_) {')
a=s.index('    process_history<0>(key_, past_key_, 0, cacheable_key_tasks_);');z=s.index('    process_history<1>',a);original=s[a:z]
s=s[:a]+'''    if (retain_outputs_) {
      process_history<0>(key_, past_key_, 0, tiling_.cache_tasks_per_tensor);
    } else {
'''+original+'''    }
'''+s[z:]
a='''    AscendC::DataCopyPad(
        local, source[row * history_elements + tile_offset], copy, pad);'''
bb='''    const uint32_t input_row = CacheIndex * tiling_.batch * tiling_.head_num + row;
    const bool bypass = retain_outputs_ &&
        (tiling_.cache_input_period == 0 || input_row % tiling_.cache_input_period != 0);
    const auto& history_source = bypass
        ? (CacheIndex == 0 ? past_key_bypass_ : past_value_bypass_)
        : source;
    AscendC::DataCopyPad(
        local, history_source[row * history_elements + tile_offset], copy, pad);'''
assert a in s;s=s.replace(a,bb,1);s=s.replace('  uint32_t cacheable_key_elements_ = 0;','  bool retain_outputs_ = false;\n  uint32_t cacheable_key_elements_ = 0;');s=s.replace('      key_bypass_, value_;','      key_bypass_, value_, past_key_bypass_, past_value_bypass_;');p.write_text(s)
