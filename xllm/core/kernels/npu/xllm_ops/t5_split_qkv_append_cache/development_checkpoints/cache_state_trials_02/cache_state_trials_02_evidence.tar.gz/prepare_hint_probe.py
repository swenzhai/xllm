# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Canary only: encode actual device tiling and hint deltas into Query raw bits."""
from pathlib import Path
import shutil
r=Path('/workspace/t5qkv-dev-20261029');a=r/'project_controlled_modes_02';b=r/'project_hint_probe_01';b.mkdir(exist_ok=False)
for n in ['common','op_kernel','op_host','framework','direct','scripts']:shutil.copytree(a/n,b/n)
for n in ['CMakeLists.txt','solution.py','.clang-format']:shutil.copy2(a/n,b/n)
p=b/'op_kernel/t5_split_qkv_append_cache_kernel.h';s=p.read_text().replace('    tiling_ = tiling;','''    tiling_ = tiling;
    input_key_address_ = reinterpret_cast<uint64_t>(past_key);
    input_value_address_ = reinterpret_cast<uint64_t>(past_value);
    output_key_address_ = reinterpret_cast<uint64_t>(key);
    output_value_address_ = reinterpret_cast<uint64_t>(value);''',1)
s=s.replace('    process_phase(history_tasks + append_tasks, tiling_.query_tasks);','''    process_phase(history_tasks + append_tasks, tiling_.query_tasks);
    if (AscendC::GetBlockIdx() == 0) {
      copy_segment(query_, qkv_, 0, tiling_.cacheable_key_rows, 1);
      copy_segment(query_, qkv_, 1, tiling_.bypass_value_cache, 1);
      copy_segment(query_, qkv_, 2, tiling_.tile_elements, 1);
      const uint64_t deltas[4] = {
        reinterpret_cast<uint64_t>(past_key_.GetPhyAddr()) - input_key_address_,
        reinterpret_cast<uint64_t>(past_value_.GetPhyAddr()) - input_value_address_,
        reinterpret_cast<uint64_t>(key_.GetPhyAddr()) - output_key_address_,
        reinterpret_cast<uint64_t>(value_.GetPhyAddr()) - output_value_address_};
      for (uint32_t index = 0; index < 4; ++index) {
        for (uint32_t bit = 0; bit < 64; ++bit) {
          copy_segment(query_, qkv_, 3 + 64 * index + bit,
                       static_cast<uint32_t>((deltas[index] >> bit) & 1), 1);
        }
      }
    }''',1)
s=s.replace('  uint32_t cacheable_key_elements_ = 0;','''  uint64_t input_key_address_ = 0;
  uint64_t input_value_address_ = 0;
  uint64_t output_key_address_ = 0;
  uint64_t output_value_address_ = 0;
  uint32_t cacheable_key_elements_ = 0;''');p.write_text(s)
