# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Extend an isolated diagnostic package; never edit the submission source."""
from pathlib import Path
import shutil
ROOT=Path('/workspace/t5qkv-dev-20261029')
old=ROOT/'project_controlled_modes_01';new=ROOT/'project_controlled_modes_02'
new.mkdir(exist_ok=False)
for name in ['common','op_kernel','op_host','framework','direct','scripts']:
    shutil.copytree(old/name,new/name)
for name in ['CMakeLists.txt','solution.py','.clang-format']:
    shutil.copy2(old/name,new/name)
for name in ['op_host/t5_split_qkv_append_cache.cpp','framework/binding.cpp']:
    p=new/name;s=p.read_text().replace('*diagnostic_mode > 4','*diagnostic_mode > 6').replace('diagnostic_mode <= 4','diagnostic_mode <= 6');p.write_text(s)
p=new/'op_kernel/t5_split_qkv_append_cache_kernel.h';s=p.read_text().replace('mode == 0 || mode == 2 || mode == 4','mode == 0 || mode == 2 || mode == 4 || mode == 6').replace('mode == 3 || mode == 4','mode == 3 || mode == 4 || mode == 5 || mode == 6').replace('mode == 2 || mode == 4) {\n      value_','mode == 2 || mode == 4 || mode == 5 || mode == 6) {\n      value_');p.write_text(s)
(new/'build_direct').mkdir();shutil.copy2(old/'build_direct/libt5qkv_direct.so',new/'build_direct/libt5qkv_direct.so')
