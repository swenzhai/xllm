# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Create the larger input-admission diagnostic from the measured partial policy."""
from pathlib import Path
import shutil
r=Path('/workspace/t5qkv-dev-20261029');a=r/'project_partial_read_01';b=r/'project_partial_read_190_01';b.mkdir(exist_ok=False)
for n in ['common','op_kernel','op_host','framework','direct','scripts','tests']:shutil.copytree(a/n,b/n)
for n in ['CMakeLists.txt','solution.py','.clang-format']:shutil.copy2(a/n,b/n)
p=b/'common/t5_split_qkv_append_cache_tiling.h';s=p.read_text().replace('uint64_t{172}','uint64_t{190}')
s=s.replace('    const uint64_t admitted_rows = candidate_rows < rows ? candidate_rows : rows;','''    uint64_t admitted_rows = candidate_rows < rows ? candidate_rows : rows;
    uint32_t divisor = tiling.cache_tiles_per_head;
    uint32_t cores = tiling.block_dim;
    while (cores != 0) {
      const uint32_t remainder = divisor % cores;
      divisor = cores;
      cores = remainder;
    }
    const uint32_t row_group = tiling.block_dim / divisor;
    if (admitted_rows >= row_group) {
      admitted_rows -= admitted_rows % row_group;
    }''',1);p.write_text(s)
