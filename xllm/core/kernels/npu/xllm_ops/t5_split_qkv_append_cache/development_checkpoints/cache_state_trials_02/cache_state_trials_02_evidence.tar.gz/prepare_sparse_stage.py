# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Create an isolated, per-call sparse cache-staging prototype."""
from pathlib import Path
import shutil,tarfile
r=Path('/workspace/t5qkv-dev-20261029');b=r/'project_sparse_stage_01';b.mkdir(exist_ok=False)
with tarfile.open(r/'baseline_sources.tar') as t:
 for m in t:
  if m.isfile() and not m.name.startswith(('docs/','development_checkpoints/')):
   p=b/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
shutil.copy2(r/'project/.clang-format',b/'.clang-format')
p=b/'op_kernel/t5_split_qkv_append_cache_kernel.h';s=p.read_text()
s=s.replace('    tiling_ = tiling;','''    tiling_ = tiling;
    const uint64_t n = uint64_t{tiling.batch} * tiling.head_num * tiling.head_dim;
    const uint64_t key_cache_bytes = 2 * n * (tiling.past_length + 5);
    const uint32_t max_tasks = (tiling.cache_tasks_per_tensor + tiling.block_dim - 1) / tiling.block_dim;
    seed_blocks_ = (max_tasks * tiling.tile_elements + 255) / 256;
    seed_elements_ = seed_blocks_ * 16;
    staged_ = tiling.bypass_value_cache != 0 && fuses_append(tiling) &&
        tiling.head_dim % 16 == 0 && seed_blocks_ <= 4095 &&
        seed_elements_ <= tiling.tile_elements && seed_elements_ <= 3 * n &&
        key_cache_bytes < uint64_t{188} * 1024 * 1024;
    if (staged_) {
      const uint64_t rows = 2 * uint64_t{tiling.batch} * tiling.head_num;
      const uint64_t row_bytes = 2 * uint64_t{tiling.past_length} * tiling.head_dim;
      uint64_t cached_rows = (uint64_t{188} * 1024 * 1024 - key_cache_bytes) / row_bytes;
      cached_rows = cached_rows < rows ? cached_rows : rows;
      cached_rows -= cached_rows % 16;
      cached_input_elements_ = cached_rows * tiling.past_length * tiling.head_dim;
    }''',1)
s=s.replace('    // The host computes admission once.', '''    if (staged_) {
      past_key_cache_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t*>(past_key), n * tiling.past_length);
      past_value_cache_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t*>(past_value), n * tiling.past_length);
      key_cache_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t*>(key), n * (tiling.past_length + 1));
      past_key_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);
      past_value_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);
      key_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);
      value_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);
    }
    // The host computes admission once.''',1)
a=s.index('    process_history<0>(key_, past_key_, 0, cacheable_key_tasks_);');z=s.index('    process_history<1>',a);orig=s[a:z]
s=s[:a]+'''    if (staged_) {
      stage_cache();
      process_history<0>(key_, past_key_, 0, tiling_.cache_tasks_per_tensor);
    } else {
'''+orig+'''    }
'''+s[z:]
mark=' private:\n';helper=''' private:
  __aicore__ inline void stage_cache() {
    const TaskRange range = partition_tasks(0, tiling_.cache_tasks_per_tensor,
        tiling_.block_dim, AscendC::GetBlockIdx());
    const CopyTask first = decode_task(tiling_, range.begin);
    const CopyTask last = decode_task(tiling_, range.end - 1);
    const uint32_t destination_first = ((first.destination_offset + 255) / 256) * 256;
    const uint32_t destination_end = last.destination_offset + last.count + last.append_count;
    const uint32_t blocks = (destination_end - destination_first + 255) / 256;
    auto seed = queue_.AllocTensor<uint16_t>();
    const AscendC::DataCopyExtParams load{1, seed_elements_ * 2, 0, 0, 0};
    const AscendC::DataCopyPadExtParams<uint16_t> pad{false, 0, 0, 0};
    AscendC::DataCopyPad(seed, qkv_, load, pad);
    queue_.EnQue(seed);
    seed = queue_.DeQue<uint16_t>();
    const AscendC::DataCopyExtParams seed_copy{static_cast<uint16_t>(blocks), 32, 0, 480, 0};
    AscendC::DataCopyPad(key_cache_[destination_first], seed, seed_copy);
    queue_.FreeTensor(seed);
    AscendC::PipeBarrier<PIPE_MTE3>();
    const uint32_t source_first = ((first.source_offset + 255) / 256) * 256;
    const uint32_t source_end = last.source_offset + last.count;
    const uint64_t cache_size = uint64_t{tiling_.batch} * tiling_.head_num * tiling_.past_length * tiling_.head_dim;
    stage_input(past_key_cache_, 0, source_first, source_end);
    stage_input(past_value_cache_, cache_size, source_first, source_end);
  }

  __aicore__ inline void stage_input(const AscendC::GlobalTensor<uint16_t>& source,
                                     uint64_t base, uint32_t first, uint32_t end) {
    if (base + first >= cached_input_elements_) {
      return;
    }
    const uint64_t limit = cached_input_elements_ - base;
    end = limit < end ? static_cast<uint32_t>(limit) : end;
    const uint32_t blocks = (end - first + 255) / 256;
    auto local = queue_.AllocTensor<uint16_t>();
    const AscendC::DataCopyExtParams copy{static_cast<uint16_t>(blocks), 32, 480, 0, 0};
    const AscendC::DataCopyPadExtParams<uint16_t> pad{false, 0, 0, 0};
    AscendC::DataCopyPad(local, source[first], copy, pad);
    queue_.EnQue(local);
    local = queue_.DeQue<uint16_t>();
    queue_.FreeTensor(local);
  }
'''
s=s.replace(mark,helper,1)
s=s.replace('  uint32_t cacheable_key_elements_ = 0;','''  bool staged_ = false;
  uint32_t seed_blocks_ = 0;
  uint32_t seed_elements_ = 0;
  uint64_t cached_input_elements_ = 0;
  uint32_t cacheable_key_elements_ = 0;''')
s=s.replace('      key_bypass_, value_;','      key_bypass_, value_, key_cache_, past_key_cache_, past_value_cache_;');p.write_text(s)
