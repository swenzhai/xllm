# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Collect real L2 counters for unsuccessful cache-admission candidates."""
import json
import os
from pathlib import Path
import shlex
import subprocess
ROOT=Path('/workspace/t5qkv-dev-20261029')


def _main() -> None:
    trials=[('partial172','project_partial_read_01','install_partial_read_01'),
            ('partial190','project_partial_read_190_01','install_partial_read_190_01'),
            ('distributed172','project_distributed_input_01','install_distributed_input_01')]
    records=[]
    for label,project,install in trials:
        package=ROOT/install/'vendors/t5qkv'
        env=dict(os.environ,ASCEND_RT_VISIBLE_DEVICES='0',ASCEND_CUSTOM_OPP_PATH=str(package),T5QKV_OPAPI_LIB=str(package/'op_api/lib/libcust_opapi.so'))
        for key in ['TASK_QUEUE_ENABLE','PYTORCH_NPU_ALLOC_CONF']:env.pop(key,None)
        command=['msprof','--application='+shlex.join(['python',str(ROOT/'public/benchmark.py'),'--solution-file',str(ROOT/project/'solution.py'),'--report',str(ROOT/'reports'/f'profile_cache_{label}_01.json')]),
                 '--output='+str(ROOT/'reports'/f'profile_cache_{label}_01'),'--aic-metrics=L2Cache']
        with (ROOT/'reports'/f'profile_cache_{label}_01.log').open('wb') as log:
            child=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
        row={'label':label,'command':command,'exit_code':child.returncode,'scope':'profile_diagnostic_only'}
        records.append(row);(ROOT/'reports/profile_failed_cache_policies_01_index.json').write_text(json.dumps(records,indent=2));print(json.dumps(row),flush=True)


if __name__=='__main__':_main()
