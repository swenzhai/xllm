# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Diagnostic timer interception preserves public prefix and fixed large outputs.

The final benchmark JSON is diagnostic, never an acceptance result: the entry
retains outputs and this observer inserts extra cache-mode measurements.
"""
import hashlib
import json
import os
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,'/workspace/t5qkv-dev-20261029/public')
import benchmark
import verify
_ORIGINAL=benchmark.measure
_ROWS=[]


def _measure(fn:object,npu:object,**kwargs:dict) -> dict:
    cells=dict(zip(fn.__code__.co_freevars,[x.cell_contents for x in fn.__closure__]))
    inputs=cells['inputs']
    if inputs[1].numel()!=33554432:return _ORIGINAL(fn,npu,**kwargs)
    entry=sys.modules['submitted_solution']
    outputs=entry._HELD
    extension=entry._impl._extension()
    npu.synchronize()
    expected=[verify.cpu_array(x).view(np.uint16).copy() for x in outputs]
    input_hashes=[hashlib.sha256(verify.cpu_array(x).tobytes()).hexdigest() for x in inputs]
    for mode in [3,0,1,2,3,4,5,6,3]:
        data=_ORIGINAL(lambda:extension.run_out_diagnostic(inputs,outputs,16,64,mode),npu)
        for tensor,reference in zip(outputs,expected):assert np.array_equal(verify.cpu_array(tensor).view(np.uint16),reference)
        row={'scope':'public_prefix_fixed_output_diagnostic','dtype':str(inputs[0].dtype),'mode':mode,
             'inputs':[x.data_ptr() for x in inputs],'outputs':[x.data_ptr() for x in outputs],
             'measurement':data,'outputs_bit_exact':True}
        _ROWS.append(row)
        Path(os.environ['T5QKV_MATRIX_REPORT']).write_text(json.dumps(_ROWS,indent=2))
        print(json.dumps(row),flush=True)
    targets=[outputs[i+1].view(-1)[:inputs[i+1].numel()] for i in range(2)]
    def _copy() -> None:
        for i in range(2):targets[i].copy_(inputs[i+1].view(-1))
    print(json.dumps({'scope':'public_prefix_native_copy','dtype':str(inputs[0].dtype),'measurement':_ORIGINAL(_copy,npu)}),flush=True)
    for tensor,h in zip(inputs,input_hashes):assert hashlib.sha256(verify.cpu_array(tensor).tobytes()).hexdigest()==h
    return _ORIGINAL(fn,npu,**kwargs)


benchmark.measure=_measure
raise SystemExit(benchmark.main())
