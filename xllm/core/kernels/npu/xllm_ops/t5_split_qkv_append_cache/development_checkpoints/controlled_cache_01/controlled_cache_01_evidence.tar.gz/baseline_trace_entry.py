# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Diagnostic address observer; never an acceptance timing entry."""
import atexit
import importlib.util
import json
import os
from pathlib import Path

_ROOT = Path('/workspace/t5qkv-dev-20261029')
_spec = importlib.util.spec_from_file_location('_baseline_solution', _ROOT/'project_controlled_baseline_01/solution.py')
_impl = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_impl)
_RECORDS = {}


def run(inputs: list, attributes: dict) -> tuple:
    outputs = _impl.run(inputs, attributes)
    if inputs[1].numel() == 33554432:
        key = str(inputs[0].dtype)
        if key not in _RECORDS:
            _RECORDS[key] = {'inputs': [x.data_ptr() for x in inputs], 'outputs': []}
        _RECORDS[key]['outputs'].append(tuple(x.data_ptr() for x in outputs))
    return outputs


def _save() -> None:
    result = {'scope': 'instrumented_diagnostic_not_acceptance', 'calls': _RECORDS,
              'sequence': 'index0 accuracy, 1..50 warmup, 51..1050 five rounds of 200'}
    Path(os.environ['T5QKV_ADDRESS_REPORT']).write_text(json.dumps(result, indent=2))


atexit.register(_save)
