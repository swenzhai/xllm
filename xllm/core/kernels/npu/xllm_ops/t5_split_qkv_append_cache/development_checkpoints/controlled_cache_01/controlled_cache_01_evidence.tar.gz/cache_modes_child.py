# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Fixed-address, fixed-schedule cache ablation; diagnostic timings only."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
import torch
import torch_npu

ROOT = Path('/workspace/t5qkv-dev-20261029')
PROJECT = ROOT/'project_controlled_modes_01'
sys.path.insert(0,str(ROOT/'public'))
import benchmark
import generate_data
import golden
import verify


def _main() -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument('--report',type=Path,required=True)
    parser.add_argument('--reverse',action='store_true')
    args=parser.parse_args()
    torch.npu.set_device(0)
    spec=importlib.util.spec_from_file_location('diagnostic_solution',PROJECT/'solution.py')
    solution=importlib.util.module_from_spec(spec);spec.loader.exec_module(solution)
    extension=solution._extension()
    public=json.loads((ROOT/'public/case.json').read_text())
    result={'scope':'fixed_outputs_cache_ablation_not_acceptance','geometry':{'tile_elements':47104,'cores':48,'cached_key_rows':175,'tiling_bytes':52},
            'modes':{'0':'current partial K / bypass V','1':'normal history reads and KV writes','2':'normal history reads / bypass KV writes','3':'bypass history reads / normal KV writes','4':'bypass history reads and KV writes'},
            'qkv_and_query':'normal in every mode','fixed_geometry_in_all_modes':True,'records':[]}
    order=[0,1,2,3,4,4,3,2,1,0]
    if args.reverse:order=list(reversed([1,0,3,2,4,4,2,3,0,1]))
    for case in public:
        if not any(x in case['case_name'] for x in ['_007_','_017_']):continue
        arrays=generate_data.generate(case)
        attrs={x['name']:x['value'] for x in case['attr_desc']}
        inputs=verify.device_inputs(case,arrays,'npu:0')
        expected=golden.calculate(arrays,attrs)
        outputs=(torch.empty((16,16,1,64),device='npu:0',dtype=inputs[0].dtype),
                 torch.empty((16,16,2049,64),device='npu:0',dtype=inputs[0].dtype),
                 torch.empty((16,16,2049,64),device='npu:0',dtype=inputs[0].dtype))
        addresses={'inputs':[x.data_ptr() for x in inputs],'outputs':[x.data_ptr() for x in outputs]}
        copy_targets=[outputs[i+1].view(-1)[:inputs[i+1].numel()] for i in range(2)]
        def copy_control() -> None:
            for index in range(2):copy_targets[index].copy_(inputs[index+1].view(-1))
        for position,mode in enumerate(order):
            extension.run_out_diagnostic(inputs,outputs,16,64,mode)
            torch.npu.synchronize()
            accuracy=verify.compare(case,arrays,outputs,expected)
            measurement=benchmark.measure(lambda:extension.run_out_diagnostic(inputs,outputs,16,64,mode),torch.npu)
            accuracy_after=verify.compare(case,arrays,outputs,expected)
            copy_measurement=benchmark.measure(copy_control,torch.npu)
            for index in range(2):
                actual=verify.cpu_array(copy_targets[index]).view(np.uint16)
                assert np.array_equal(actual,arrays[index+1].reshape(-1).view(np.uint16))
            row={'case_name':case['case_name'],'position':position,'mode':mode,'addresses':addresses,
                 'accuracy_before':accuracy,'accuracy_after':accuracy_after,'measurement':measurement,
                 'native_contiguous_copy_128MiB':copy_measurement}
            result['records'].append(row)
            args.report.write_text(json.dumps(result,indent=2))
            print(json.dumps(row),flush=True)
        for tensor,original in zip(inputs,arrays):
            assert np.array_equal(verify.cpu_array(tensor).view(np.uint16),original.view(np.uint16))
        del copy_targets,outputs,inputs
    result['status']='diagnostic_completed'
    args.report.write_text(json.dumps(result,indent=2))


if __name__=='__main__':
    _main()
