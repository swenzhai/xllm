# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Repeat one frozen SDK package, retaining every original child result."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/t5qkv-dev-20261029')
PROJECT = ROOT/'project_controlled_baseline_01'
INSTALL = ROOT/'install_host_policy_01/vendors/t5qkv'
REPORT = ROOT/'reports/controlled_baseline_repeats_01'


def _snapshot() -> dict:
    files = [p for p in PROJECT.rglob('*') if p.is_file()
             and not any(x.startswith('build') or x in ['__pycache__','docs','development_checkpoints'] for x in p.relative_to(PROJECT).parts[:-1])]
    files += [p for p in INSTALL.rglob('*') if p.is_file()]
    files += list((ROOT/'public').glob('*.py')) + list((ROOT/'public').glob('*.json'))
    files += [PROJECT/'build_direct/libt5qkv_direct.so']
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}


def _main() -> None:
    REPORT.mkdir(exist_ok=False)
    before = _snapshot()
    (REPORT/'pretest_manifest.json').write_text(json.dumps(before, indent=2))
    env = dict(os.environ, ASCEND_RT_VISIBLE_DEVICES='0', ASCEND_CUSTOM_OPP_PATH=str(INSTALL),
               T5QKV_OPAPI_LIB=str(INSTALL/'op_api/lib/libcust_opapi.so'))
    for key in ['TASK_QUEUE_ENABLE','PYTORCH_NPU_ALLOC_CONF','ASCEND_LAUNCH_BLOCKING']:
        env.pop(key, None)
    records = []
    for index, traced in enumerate([False, True, True, False, False, True]):
        label = f'{index:02}_'+('traced' if traced else 'plain')
        with (REPORT/(label+'_device_before.log')).open('wb') as log:
            subprocess.run(['npu-smi','info'], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        entry = ROOT/'baseline_trace_entry.py' if traced else PROJECT/'solution.py'
        env['T5QKV_ADDRESS_REPORT'] = str(REPORT/(label+'_addresses.json'))
        command = [sys.executable, str(ROOT/'public/benchmark.py'), '--solution-file', str(entry), '--report', str(REPORT/(label+'.json'))]
        with (REPORT/(label+'.log')).open('wb') as log:
            child = subprocess.run(command, cwd=ROOT/'public', env=env, stdout=log, stderr=subprocess.STDOUT)
        result = json.loads((REPORT/(label+'.json')).read_text())
        assert result.get('npu_executed') and not result.get('error'), result
        row = {'label':label,'instrumented':traced,'command':command,'exit_code':child.returncode,
               'status':result['status'],'cases':[{ 'case_name':c['case_name'], **c['results']['custom']} for c in result['cases']]}
        if traced:
            addr = json.loads((REPORT/(label+'_addresses.json')).read_text())
            row['address_summary'] = {k:{'calls':len(v['outputs']), 'timed_unique_output_triples':len({tuple(x) for x in v['outputs'][51:]}), 'input_addresses':v['inputs']} for k,v in addr['calls'].items()}
        with (REPORT/(label+'_device_after.log')).open('wb') as log:
            subprocess.run(['npu-smi','info'], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        records.append(row)
        (REPORT/'DERIVED_SUMMARY.json').write_text(json.dumps(records,indent=2))
        print(json.dumps(row),flush=True)
    after = _snapshot()
    (REPORT/'posttest_manifest.json').write_text(json.dumps(after,indent=2))
    assert before == after


if __name__ == '__main__':
    _main()
