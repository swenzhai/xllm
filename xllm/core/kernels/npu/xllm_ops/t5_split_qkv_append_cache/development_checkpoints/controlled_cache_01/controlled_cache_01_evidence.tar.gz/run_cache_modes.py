# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Sequential fixed-address cache ablations with full artifact snapshots."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path('/workspace/t5qkv-dev-20261029')
PROJECT=ROOT/'project_controlled_modes_01'
INSTALL=ROOT/'install_controlled_modes_01/vendors/t5qkv'
REPORT=ROOT/'reports/controlled_cache_modes_01'


def _snapshot() -> dict:
    files=[p for p in PROJECT.rglob('*') if p.is_file() and not any(x.startswith('build') or x=='__pycache__' for x in p.relative_to(PROJECT).parts[:-1])]
    files += [p for p in INSTALL.rglob('*') if p.is_file()]
    files += [PROJECT/'build_direct/libt5qkv_direct.so',ROOT/'cache_modes_child.py',Path(__file__)]
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}


def _main() -> None:
    REPORT.mkdir(exist_ok=False)
    before=_snapshot();(REPORT/'pretest_manifest.json').write_text(json.dumps(before,indent=2))
    env=dict(os.environ,ASCEND_RT_VISIBLE_DEVICES='0',ASCEND_CUSTOM_OPP_PATH=str(INSTALL),T5QKV_OPAPI_LIB=str(INSTALL/'op_api/lib/libcust_opapi.so'))
    for key in ['TASK_QUEUE_ENABLE','PYTORCH_NPU_ALLOC_CONF','ASCEND_LAUNCH_BLOCKING']:env.pop(key,None)
    records=[]
    for index in range(4):
        path=REPORT/f'process_{index:02}.json'
        cmd=[sys.executable,str(ROOT/'cache_modes_child.py'),'--report',str(path)]
        if index%2:cmd+=['--reverse']
        with path.with_suffix('.log').open('wb') as log:
            child=subprocess.run(cmd,env=env,cwd=PROJECT,stdout=log,stderr=subprocess.STDOUT)
        records.append({'index':index,'command':cmd,'exit_code':child.returncode})
        (REPORT/'execution_index.json').write_text(json.dumps(records,indent=2))
        print(json.dumps(records[-1]),flush=True)
        if child.returncode:raise RuntimeError('Diagnostic child failed; inspect original log')
    after=_snapshot();(REPORT/'posttest_manifest.json').write_text(json.dumps(after,indent=2));assert before==after


if __name__=='__main__':_main()
