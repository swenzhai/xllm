# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Compile fixed-geometry cache-budget controls into one diagnostic binary."""
from pathlib import Path
import shutil
r=Path('/workspace/t5qkv-dev-20261029');a=r/'project_controlled_modes_02';b=r/'project_balance_matrix_01';b.mkdir(exist_ok=False)
for n in ['common','op_kernel','op_host','framework','direct','scripts']:shutil.copytree(a/n,b/n)
for n in ['CMakeLists.txt','solution.py','.clang-format']:shutil.copy2(a/n,b/n)
for name in ['op_host/t5_split_qkv_append_cache.cpp','framework/binding.cpp']:
 p=b/name;s=p.read_text().replace('*diagnostic_mode > 6','*diagnostic_mode > 13').replace('diagnostic_mode <= 6','diagnostic_mode <= 13');p.write_text(s)
p=b/'op_kernel/t5_split_qkv_append_cache_kernel.h';s=p.read_text().replace('    const uint32_t mode = tiling.bypass_value_cache >> 8;','''    const uint32_t mode = tiling.bypass_value_cache >> 8;
    if (mode >= 7) {
      const uint32_t rows[7] = {0, 64, 128, 160, 192, 224, 240};
      const uint32_t total = tiling.batch * tiling.head_num;
      const uint32_t admitted = rows[mode - 7] < total ? rows[mode - 7] : total;
      normal_value_tasks_ = admitted * tiling.cache_tiles_per_head;
      balanced_ = true;
      past_value_bypass_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t*>(past_value), query_elements * tiling.past_length);
      past_value_bypass_.SetL2CacheHint(AscendC::CacheMode::CACHE_MODE_DISABLE);
    }''')
s=s.replace('mode == 4 || mode == 5 || mode == 6) {\n      value_', 'mode == 4 || mode == 5 || mode == 6 || mode >= 7) {\n      value_')
a=s.index('    process_history<0>(key_, past_key_, 0, cacheable_key_tasks_);');z=s.index('    process_phase(history_tasks, append_tasks);',a);orig=s[a:z]
s=s[:a]+'''    if (balanced_) {
      process_history<0>(key_, past_key_, 0, tiling_.cache_tasks_per_tensor);
      process_history<1>(value_, past_value_, 0, normal_value_tasks_);
      process_history<1>(value_, past_value_bypass_, normal_value_tasks_, tiling_.cache_tasks_per_tensor - normal_value_tasks_);
    } else {
'''+orig+'''    }
'''+s[z:]
s=s.replace('  uint32_t cacheable_key_elements_ = 0;','  bool balanced_ = false;\n  uint32_t normal_value_tasks_ = 0;\n  uint32_t cacheable_key_elements_ = 0;').replace('      key_bypass_, value_;','      key_bypass_, value_, past_value_bypass_;');p.write_text(s)
(b/'build_direct').mkdir();shutil.copy2(r/'project_controlled_modes_02/build_direct/libt5qkv_direct.so',b/'build_direct/libt5qkv_direct.so')
