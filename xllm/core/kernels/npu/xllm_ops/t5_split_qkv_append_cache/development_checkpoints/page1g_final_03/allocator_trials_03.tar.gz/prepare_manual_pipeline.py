# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Manual event pairs and one continuous history pipeline across cache classes."""
from pathlib import Path
import shutil
r=Path('/workspace/t5qkv-dev-20261029');a=r/'project_read_balanced_01';b=r/'project_manual_pipeline_01';b.mkdir(exist_ok=False)
for n in ['common','op_kernel','op_host','framework','direct','scripts','tests']:shutil.copytree(a/n,b/n)
for n in ['CMakeLists.txt','solution.py','.clang-format']:shutil.copy2(a/n,b/n)
p=b/'op_kernel/t5_split_qkv_append_cache_kernel.h';s=p.read_text().replace('uint64_t{188}','uint64_t{190}')
s=s.replace('''    pipe_.InitBuffer(
        queue_, /*num=*/2, tiling.tile_elements * sizeof(uint16_t));''','''    pipe_.InitBuffer(buffer_, 2 * tiling.tile_elements * sizeof(uint16_t));
    for (uint32_t slot = 0; slot < 2; ++slot) {
      read_events_[slot] = static_cast<int32_t>(pipe_.AllocEventID<AscendC::HardEvent::MTE2_MTE3>());
      write_events_[slot] = static_cast<int32_t>(pipe_.AllocEventID<AscendC::HardEvent::MTE3_MTE2>());
    }''')
x=s.index('  __aicore__ inline void process() {');y=s.index('\n private:',x)
s=s[:x]+'''  __aicore__ inline void process() {
    const uint32_t history_tasks = 2 * tiling_.cache_tasks_per_tensor;
    const uint32_t append_tasks = fuses_append(tiling_) ? 0 : 2 * tiling_.batch * tiling_.head_num;
    const uint32_t core = AscendC::GetBlockIdx();
    if (balanced_) {
      ranges_[0] = partition_tasks(0, tiling_.cache_tasks_per_tensor, tiling_.block_dim, core);
      ranges_[1] = partition_tasks(0, normal_value_tasks_, tiling_.block_dim, core);
      ranges_[2] = partition_tasks(normal_value_tasks_, tiling_.cache_tasks_per_tensor - normal_value_tasks_, tiling_.block_dim, core);
    } else {
      ranges_[0] = partition_tasks(0, cacheable_key_tasks_, tiling_.block_dim, core);
      ranges_[1] = partition_tasks(cacheable_key_tasks_, tiling_.cache_tasks_per_tensor - cacheable_key_tasks_, tiling_.block_dim, core);
      ranges_[2] = partition_tasks(0, tiling_.cache_tasks_per_tensor, tiling_.block_dim, core);
    }
    process_history_pipeline();
    process_phase(history_tasks, append_tasks);
    process_phase(history_tasks + append_tasks, tiling_.query_tasks);
    for (uint32_t slot = 0; slot < 2; ++slot) {
      pipe_.ReleaseEventID<AscendC::HardEvent::MTE2_MTE3>(read_events_[slot]);
      pipe_.ReleaseEventID<AscendC::HardEvent::MTE3_MTE2>(write_events_[slot]);
    }
  }
''' + s[y:]
x=s.index('  struct HistoryWrite {');y=s.index('  __aicore__ inline void process_phase',x)
s=s[:x]+'''  struct HistoryWrite {
    uint32_t destination_offset;
    uint32_t count;
    uint32_t output;
  };

  struct Cursor {
    uint32_t phase;
    uint32_t task;
    uint32_t row;
    uint32_t tile;
  };

  __aicore__ inline void enter_phase(Cursor& cursor) {
    while (cursor.phase < 3 && ranges_[cursor.phase].begin == ranges_[cursor.phase].end) {
      ++cursor.phase;
    }
    if (cursor.phase < 3) {
      cursor.task = ranges_[cursor.phase].begin;
      cursor.row = cursor.task / tiling_.cache_tiles_per_head;
      cursor.tile = cursor.task % tiling_.cache_tiles_per_head;
    }
  }

  __aicore__ inline void advance(Cursor& cursor) {
    ++cursor.task;
    if (cursor.task == ranges_[cursor.phase].end) {
      ++cursor.phase;
      enter_phase(cursor);
    } else {
      ++cursor.tile;
      if (cursor.tile == tiling_.cache_tiles_per_head) {
        cursor.tile = 0;
        ++cursor.row;
      }
    }
  }

  __aicore__ inline HistoryWrite prefetch(const Cursor& cursor, uint32_t slot) {
    const bool value = balanced_ ? cursor.phase != 0 : cursor.phase == 2;
    const auto& source = !value ? past_key_ :
        (balanced_ && cursor.phase == 2 ? past_value_bypass_ : past_value_);
    const uint32_t history_elements = tiling_.past_length * tiling_.head_dim;
    const uint32_t tile_offset = cursor.tile * tiling_.tile_elements;
    const uint32_t remaining = history_elements - tile_offset;
    const uint32_t count = remaining < tiling_.tile_elements ? remaining : tiling_.tile_elements;
    const bool append = fuses_append(tiling_) && cursor.tile + 1 == tiling_.cache_tiles_per_head;
    auto local = buffer_.Get<uint16_t>()[slot * tiling_.tile_elements];
    const AscendC::DataCopyExtParams copy{1, count * 2, 0, 0, 0};
    const AscendC::DataCopyPadExtParams<uint16_t> pad{false, 0, 0, 0};
    AscendC::DataCopyPad(local, source[cursor.row * history_elements + tile_offset], copy, pad);
    if (append) {
      const uint32_t batch = cursor.row / tiling_.head_num;
      const uint32_t head = cursor.row % tiling_.head_num;
      const uint32_t hd = tiling_.head_num * tiling_.head_dim;
      const uint32_t append_offset = batch * 3 * hd + (value ? 2 : 1) * hd + head * tiling_.head_dim;
      const AscendC::DataCopyExtParams tail{1, tiling_.head_dim * 2, 0, 0, 0};
      AscendC::DataCopyPad(local[count], qkv_[append_offset], tail, pad);
    }
    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(read_events_[slot]);
    return {cursor.row * (history_elements + tiling_.head_dim) + tile_offset,
            count + (append ? tiling_.head_dim : 0), balanced_ ? (value ? 2U : 0U) : cursor.phase};
  }

  __aicore__ inline void process_history_pipeline() {
    uint32_t total = 0;
    for (uint32_t phase = 0; phase < 3; ++phase) {
      total += ranges_[phase].end - ranges_[phase].begin;
    }
    if (total == 0) {
      return;
    }
    Cursor cursor{};
    enter_phase(cursor);
    uint32_t slot = 0;
    bool used[2] = {true, false};
    HistoryWrite current = prefetch(cursor, slot);
    advance(cursor);
    for (uint32_t index = 0; index < total; ++index) {
      HistoryWrite next{};
      const uint32_t next_slot = slot ^ 1;
      if (index + 1 < total) {
        if (used[next_slot]) {
          AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(write_events_[next_slot]);
        }
        next = prefetch(cursor, next_slot);
        used[next_slot] = true;
        advance(cursor);
      }
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(read_events_[slot]);
      auto local = buffer_.Get<uint16_t>()[slot * tiling_.tile_elements];
      auto& destination = current.output == 0 ? key_ : (current.output == 1 ? key_bypass_ : value_);
      const AscendC::DataCopyExtParams copy{1, current.count * 2, 0, 0, 0};
      AscendC::DataCopyPad(destination[current.destination_offset], local, copy);
      AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(write_events_[slot]);
      current = next;
      slot = next_slot;
    }
    for (uint32_t index = 0; index < 2; ++index) {
      if (used[index]) {
        AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(write_events_[index]);
      }
    }
  }

''' + s[y:]
x=s.index('    // Each segment starts');y=s.index('\n  bool balanced_',x)
s=s[:x]+'''    auto local = buffer_.Get<uint16_t>();
    const AscendC::DataCopyExtParams copy{1, count * 2, 0, 0, 0};
    const AscendC::DataCopyPadExtParams<uint16_t> pad{false, 0, 0, 0};
    AscendC::DataCopyPad(local, source[source_offset], copy, pad);
    AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE3>(read_events_[0]);
    AscendC::WaitFlag<AscendC::HardEvent::MTE2_MTE3>(read_events_[0]);
    AscendC::DataCopyPad(destination[destination_offset], local, copy);
    AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(write_events_[0]);
    AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(write_events_[0]);
  }
''' + s[y:]
x=s.index('  AscendC::TQueBind<');y=s.index('  AscendC::GlobalTensor',x)
s=s[:x]+'''  AscendC::TBuf<AscendC::TPosition::VECCALC> buffer_;
  int32_t read_events_[2]{};
  int32_t write_events_[2]{};
  TaskRange ranges_[3]{};
''' + s[y:]
assert 'queue_' not in s
p.write_text(s)
