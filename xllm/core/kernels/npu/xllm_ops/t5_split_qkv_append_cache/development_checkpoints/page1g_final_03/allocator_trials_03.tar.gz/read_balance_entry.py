# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Allocating diagnostic cache-budget entry, only the two large official cases."""
import importlib.util
import os
from pathlib import Path
import torch
ROOT=Path('/workspace/t5qkv-dev-20261029')
_spec=importlib.util.spec_from_file_location('balance_solution',ROOT/'project_balance_matrix_01/solution.py')
_impl=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_impl)
_MODE=int(os.environ['T5QKV_BALANCE_MODE'])


def run(inputs:list,attributes:dict) -> tuple:
    if inputs[1].numel()!=33554432:return _impl.run(inputs,attributes)
    b,h,l,d=inputs[1].shape
    outputs=(torch.empty((b,h,1,d),device=inputs[0].device,dtype=inputs[0].dtype),
             torch.empty((b,h,l+1,d),device=inputs[0].device,dtype=inputs[0].dtype),
             torch.empty((b,h,l+1,d),device=inputs[0].device,dtype=inputs[0].dtype))
    _impl._extension().run_out_diagnostic(inputs,outputs,h,d,_MODE)
    return outputs
