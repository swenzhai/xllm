# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Independent-process budget controls; no unmeasured warmup or retained outputs."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/workspace/t5qkv-dev-20261029')
PROJECT=ROOT/'project_balance_matrix_01'
INSTALL=ROOT/'install_balance_matrix_01/vendors/t5qkv'
REPORT=ROOT/'reports/cold_balance_matrix_01'


def _snapshot() -> dict:
    files=[p for p in PROJECT.rglob('*') if p.is_file() and not any(x.startswith('build') or x=='__pycache__' for x in p.relative_to(PROJECT).parts[:-1])]
    files += [p for p in INSTALL.rglob('*') if p.is_file()]
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}


def _main() -> None:
    REPORT.mkdir(exist_ok=False);before=_snapshot();(REPORT/'pretest_manifest.json').write_text(json.dumps(before,indent=2))
    env=dict(os.environ,ASCEND_RT_VISIBLE_DEVICES='0',ASCEND_CUSTOM_OPP_PATH=str(INSTALL),T5QKV_OPAPI_LIB=str(INSTALL/'op_api/lib/libcust_opapi.so'))
    for key in ['TASK_QUEUE_ENABLE','PYTORCH_NPU_ALLOC_CONF']:env.pop(key,None)
    rows=[]
    for index,mode in enumerate([7,9,11,8,10,12,13]):
        env['T5QKV_BALANCE_MODE']=str(mode)
        output=REPORT/f'{index:02}_mode{mode}.json'
        command=[sys.executable,str(ROOT/'public/benchmark.py'),'--solution-file',str(ROOT/'read_balance_entry.py'),'--report',str(output)]
        with output.with_suffix('.log').open('wb') as log:
            child=subprocess.run(command,env=env,cwd=ROOT/'public',stdout=log,stderr=subprocess.STDOUT)
        a=json.loads(output.read_text());assert a.get('npu_executed') and not a.get('error'),a
        row={'mode':mode,'exit_code':child.returncode,'command':command,'status':a['status'],'results':[{'case_name':c['case_name'],**c['results']['custom']} for c in a['cases']]}
        rows.append(row);(REPORT/'DERIVED_SUMMARY.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
    after=_snapshot();(REPORT/'posttest_manifest.json').write_text(json.dumps(after,indent=2));assert before==after


if __name__=='__main__':_main()
