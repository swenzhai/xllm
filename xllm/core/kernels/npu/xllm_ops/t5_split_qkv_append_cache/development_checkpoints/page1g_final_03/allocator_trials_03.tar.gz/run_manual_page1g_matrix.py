# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""One frozen manual kernel; independent native/expandable allocator processes."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/workspace/t5qkv-dev-20261029')
PROJECT=ROOT/'project_manual_pipeline_01'
INSTALL=ROOT/'install_manual_pipeline_01/vendors/t5qkv'
REPORT=ROOT/'reports/manual_page1g_matrix_01'


def _snapshot() -> dict:
    files=[p for p in PROJECT.rglob('*') if p.is_file() and not any(x.startswith('build') or x=='__pycache__' for x in p.relative_to(PROJECT).parts[:-1])]+[p for p in INSTALL.rglob('*') if p.is_file()]
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}


def _main() -> None:
    REPORT.mkdir(exist_ok=False);before=_snapshot();(REPORT/'pretest_manifest.json').write_text(json.dumps(before,indent=2))
    env=dict(os.environ,ASCEND_RT_VISIBLE_DEVICES='0',ASCEND_CUSTOM_OPP_PATH=str(INSTALL),T5QKV_OPAPI_LIB=str(INSTALL/'op_api/lib/libcust_opapi.so'))
    for key in ['TASK_QUEUE_ENABLE','PYTORCH_NPU_ALLOC_CONF']:env.pop(key,None)
    rows=[]
    for index,expand in enumerate([True,True,True,True]):
        if expand:env['PYTORCH_NPU_ALLOC_CONF']='page_size:1g'
        else:env.pop('PYTORCH_NPU_ALLOC_CONF',None)
        label=f'{index:02}_'+('page1g' if expand else 'native');output=REPORT/(label+'.json')
        cmd=[sys.executable,str(ROOT/'public/benchmark.py'),'--solution-file',str(PROJECT/'solution.py'),'--report',str(output)]
        with output.with_suffix('.log').open('wb') as log:
            child=subprocess.run(cmd,env=env,cwd=ROOT/'public',stdout=log,stderr=subprocess.STDOUT)
        a=json.loads(output.read_text());assert a.get('npu_executed') and not a.get('error'),a
        row={'label':label,'allocator_env':env.get('PYTORCH_NPU_ALLOC_CONF'),'command':cmd,'exit_code':child.returncode,'status':a['status'],'cases':[{'case_name':c['case_name'],**c['results']['custom']} for c in a['cases']]}
        rows.append(row);(REPORT/'DERIVED_SUMMARY.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
    after=_snapshot();(REPORT/'posttest_manifest.json').write_text(json.dumps(after,indent=2));assert before==after


if __name__=='__main__':_main()
