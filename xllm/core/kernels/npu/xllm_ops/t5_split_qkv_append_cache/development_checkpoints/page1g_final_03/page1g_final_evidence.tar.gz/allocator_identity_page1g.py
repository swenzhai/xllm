# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Separate-process runtime/allocator identity; no acceptance latency claim."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import numpy as np
import torch
import torch_npu
import ml_dtypes
ROOT=Path('/workspace/t5qkv-dev-20261029')
PROJECT=ROOT/'project_acceptance_page1g_01'
sys.path.insert(0,str(ROOT/'public'))
import generate_data
import golden
import verify


def _state() -> dict:
    stats=torch.npu.memory_stats(0)
    return {'allocated':torch.npu.memory_allocated(0),'active':stats['active_bytes.all.current'],
            'reserved':torch.npu.memory_reserved(0),'peak_reserved':torch.npu.max_memory_reserved(0)}


def _main() -> None:
    torch.npu.set_device(0)
    spec=importlib.util.spec_from_file_location('accepted_solution',PROJECT/'solution.py')
    solution=importlib.util.module_from_spec(spec);spec.loader.exec_module(solution)
    case=next(c for c in json.loads((ROOT/'public/case.json').read_text()) if '_007_' in c['case_name'])
    arrays=generate_data.generate(case);inputs=verify.device_inputs(case,arrays,'npu:0')
    expected=golden.calculate(arrays,{'headNum':16,'headDim':64})
    before=_state();outputs=solution.run(inputs,{'headNum':16,'headDim':64});torch.npu.synchronize()
    accuracy=verify.compare(case,arrays,outputs,expected);during=_state()
    snapshot=torch.npu.memory_snapshot()
    mapped=set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        pieces=line.split()
        if pieces and pieces[-1].startswith(str(ROOT)) and '.so' in pieces[-1]:mapped.add(Path(pieces[-1]))
    loaded={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(mapped)}
    del outputs;torch.npu.synchronize();after=_state()
    assert before['allocated']==after['allocated'] and before['active']==after['active']
    data={'scope':'runtime_identity_and_allocator_pool_not_device_wide_HBM_peak','python':sys.version,
          'torch':torch.__version__,'torch_npu':torch_npu.__version__,'numpy':np.__version__,'ml_dtypes':ml_dtypes.__version__,
          'platform':platform.platform(),'os_release':Path('/etc/os-release').read_text(),
          'device_name':torch.npu.get_device_name(0),'visible_device_count':torch.npu.device_count(),
          'runtime_options':{k:os.environ.get(k) for k in ['ASCEND_RT_VISIBLE_DEVICES','PYTORCH_NPU_ALLOC_CONF','TASK_QUEUE_ENABLE','ASCEND_CUSTOM_OPP_PATH','T5QKV_OPAPI_LIB']},
          'before_outputs':before,'with_outputs':during,'after_output_release':after,
          'allocator_snapshot':snapshot,'loaded_files':loaded,'accuracy':accuracy,
          'driver_npu_smi_stdout':subprocess.check_output(['npu-smi','info'],text=True),
          'cann_installation_info':Path('/usr/local/Ascend/cann-9.1.0/aarch64-linux/ascend_toolkit_install.info').read_text()}
    out=ROOT/'reports/acceptance_page1g_final_02/runtime_identity.json';out.write_text(json.dumps(data,indent=2));print(json.dumps(data),flush=True)


if __name__=='__main__':_main()
