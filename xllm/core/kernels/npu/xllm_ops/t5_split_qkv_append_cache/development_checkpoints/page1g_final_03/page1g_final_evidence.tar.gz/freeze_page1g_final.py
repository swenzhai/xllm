"""Freeze immutable final validation evidence and runnable build artifacts."""
import hashlib
import json
from pathlib import Path
import tarfile

root = Path('/workspace/t5qkv-dev-20261029')
project = root/'project_acceptance_page1g_01'
install = root/'install_acceptance_page1g_01/vendors/t5qkv'
report = root/'reports/acceptance_page1g_final_02'
before = json.loads((report/'pretest_manifest.json').read_text())
assert before == json.loads((report/'posttest_manifest.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p,h in before.items())
files = set(Path(p) for p in before)
files.update(p for p in report.rglob('*') if p.is_file())
files.update(p for p in (root/'reports').glob('visible_page1g_final*') if p.is_file())
files.update(p for p in (root/'reports/visible_page1g_final_performance').rglob('*') if p.is_file())
files.update(p for p in (root/'reports').glob('*acceptance_page1g*log') if p.is_file())
files.update([root/'visible_page1g_final.py', Path(__file__), project/'build_acceptance/custom_opp_ubuntu_aarch64.run'])
index = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
manifest = root/'reports/page1g_final_archive_manifest.json'
manifest.write_text(json.dumps(index,indent=2)+'\n')
archive = root/'reports/page1g_final_evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(files | {manifest}): tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
print(json.dumps({'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(index),'bytes':archive.stat().st_size},indent=2))
