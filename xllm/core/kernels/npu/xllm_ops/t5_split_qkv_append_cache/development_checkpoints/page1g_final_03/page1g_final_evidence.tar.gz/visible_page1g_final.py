# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Run actual validation and display a compact view of the resulting JSON."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/t5qkv-dev-20261029')
mode = sys.argv[1]
os.environ['PYTORCH_NPU_ALLOC_CONF'] = 'page_size:1g'
os.environ['ASCEND_RT_VISIBLE_DEVICES'] = '0'
print('Allocator: page_size:1g; device: 0; fresh process; original timer unchanged', flush=True)
prefix = root / 'install_acceptance_page1g_01/vendors/t5qkv'
os.environ['ASCEND_CUSTOM_OPP_PATH'] = str(prefix)
os.environ['T5QKV_OPAPI_LIB'] = str(prefix / 'op_api/lib/libcust_opapi.so')
report = root / f'reports/visible_page1g_final_{mode}.json'
if report.exists():
    raise RuntimeError('Original results already exist; choose a new run')
project, package = root/'project_acceptance_page1g_01', root/'public'
if mode == 'accuracy':
    cmd = [sys.executable, str(package/'verify.py'), '--solution-file', str(project/'solution.py'), '--report', str(report)]
elif mode == 'performance':
    cmd = [sys.executable, str(project/'tests/compare_same_device.py'), '--package-dir', str(package), '--solution-file', str(project/'solution.py'), '--report', str(report)]
elif mode == 'memory':
    cmd = [sys.executable, str(project/'tests/acceptance.py'), '--package-dir', str(package), '--solution-file', str(project/'solution.py'), '--groups', 'memory', '--report', str(report)]
else:
    raise ValueError(mode)
print('Actual validation command:', ' '.join(cmd), flush=True)
with report.with_suffix('.log').open('wb') as log:
    result = subprocess.run(cmd, cwd=package, stdout=log, stderr=subprocess.STDOUT)
print('Child exit code:', result.returncode, flush=True)
if not report.is_file():
    print(report.with_suffix('.log').read_text()[-3000:], flush=True)
    raise SystemExit(result.returncode or 1)
d = json.loads(report.read_text())
print('Result JSON:', report, flush=True)
print('Status:', d['status'], flush=True)
print('Displayed values below are derived from this actual result JSON.', flush=True)
if mode == 'performance':
    print('Case                                              Custom us   Baseline us  Limit us  Check', flush=True)
    for c in d['cases']:
        print(f"{c['case_name']:49} {c['results']['custom']['wall_us_median']:9.3f} {c['results']['views_concat_q_copy']['wall_us_median']:12.3f} {c['max_wall_us']:9}  {c['absolute_status']}", flush=True)
    print('Warmup=50; iterations=200; rounds=5; original public timer; separate processes.', flush=True)
elif mode == 'memory':
    print('Case                                              Active peak delta    Limit       Recovery', flush=True)
    for c in d['records']:
        v=c['details']
        print(f"{c['case_name']:49} {v['peak_active_delta']:17} {v['limit_bytes']:12}  {v['active_before']==v['active_after']}", flush=True)
    print('Explicit global workspace=0; UB=2 x 92 KiB; original allocator records retained.', flush=True)
else:
    print(json.dumps(d.get('summary', {})), flush=True)
    for c in d.get('cases', d.get('records', [])):
        print(c['case_name'], c['status'], flush=True)
print('Kernel SHA256:',hashlib.sha256((project/'op_kernel/t5_split_qkv_append_cache_kernel.h').read_bytes()).hexdigest(),flush=True)
print('API library SHA256:',hashlib.sha256(Path(os.environ['T5QKV_OPAPI_LIB']).read_bytes()).hexdigest(),flush=True)
print('Screenshot is of this actual execution; original child output:', report.with_suffix('.log'), flush=True)
raise SystemExit(result.returncode)
