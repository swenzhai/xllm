# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Diagnostic direct-entry adapter; not the mandatory ACLNN submission entry."""
import sys
sys.path.insert(0, '/workspace/t5qkv-dev-20261029/project')
from solution import run_direct as run
