from pathlib import Path
import sys
sys.path.insert(0,'/workspace/t5qkv-dev-20261029/public')
import benchmark
original=benchmark.measure
def probe(fn,npu):
 cells=dict(zip(fn.__code__.co_freevars,[c.cell_contents for c in fn.__closure__]))
 inputs=cells['inputs']
 out=fn(); npu.synchronize()
 print('ALLOCATION_ADDRESSES',[(tuple(x.shape),hex(x.data_ptr()),x.numel()*x.element_size()) for x in (*inputs,*out)],flush=True)
 del out
 return original(fn,npu)
benchmark.measure=probe
raise SystemExit(benchmark.main())
