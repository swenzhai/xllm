import sys
sys.path.insert(0,'/workspace/t5qkv-dev-20261029/public')
import benchmark
load=benchmark.load_module
traces={}
def intercept(name,path):
 m=load(name,path)
 if name=='submitted_solution':
  run=m.run
  def tracked(inputs,attrs):
   out=run(inputs,attrs)
   if inputs[1].shape[2]==2048:
    import torch
    key=str(inputs[1].dtype)
    traces.setdefault(key,[]).append(([x.data_ptr() for x in out],torch.npu.memory_allocated(),torch.npu.memory_stats().get('active_bytes.all.current')))
   return out
  m.run=tracked
 return m
benchmark.load_module=intercept
result=benchmark.main()
for dtype,seq in traces.items():
 print('ALLOCATION_TRACE',dtype,'calls',len(seq),'unique_key_addresses',len({x[0][1] for x in seq}),'max_allocated',max(x[1] for x in seq),'max_active',max(x[2] for x in seq),'first_12',seq[:12],flush=True)
raise SystemExit(result)
