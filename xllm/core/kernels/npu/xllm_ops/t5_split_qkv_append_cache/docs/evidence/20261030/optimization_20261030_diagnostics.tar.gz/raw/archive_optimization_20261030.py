# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Archive diagnostic evidence, without converting failures into acceptance."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

root = Path('/workspace/t5qkv-dev-20261029')
destination = root / 'optimization_20261030_diagnostics'
destination.mkdir(exist_ok=False)
items = []
for p in (root / 'reports').rglob('*'):
    if p.is_file() and p.suffix in {'.log', '.json', '.csv', '.h', '.cpp', '.txt'}:
        items.append(p)
for folder in [root / 'project', root / 'public']:
    for p in folder.rglob('*'):
        relative = p.relative_to(folder)
        if p.is_file() and not any(part.startswith('build') or part == '__pycache__' for part in relative.parts[:-1]):
            items.append(p)
items += [root / 'project/build_direct/libt5qkv_direct.so',
          root / 'project/build_cache_phase172_01/custom_opp_ubuntu_aarch64.run']
items += [p for p in (root / 'install_cache_phase172_01').rglob('*') if p.is_file()]
items += [p for p in root.glob('*.py')]
items += [root / 'env/activate.sh']
items += [p for p in root.glob('stripe176*source.tar.gz')]
items += [root / 'checkpoint172_final_source.tar.gz']
manifest = {}
for p in sorted(set(items)):
    if not p.is_file():
        raise FileNotFoundError(p)
    relative = p.relative_to(root)
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(p, target)
    digest = hashlib.sha256(p.read_bytes()).hexdigest()
    assert digest == hashlib.sha256(target.read_bytes()).hexdigest()
    manifest[str(relative)] = digest
(destination / 'SERVER_MANIFEST.json').write_text(json.dumps(manifest, indent=2))
archive = root / 'optimization_20261030_diagnostics.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(destination, arcname='raw')
print(json.dumps({'status': 'diagnostics_only_not_acceptance', 'archive': str(archive),
                  'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'bytes': archive.stat().st_size, 'files': len(manifest)}, indent=2))
