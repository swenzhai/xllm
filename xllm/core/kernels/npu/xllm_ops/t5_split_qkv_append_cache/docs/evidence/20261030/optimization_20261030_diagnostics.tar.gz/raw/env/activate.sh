# Source this file in the current shell; all task caches stay under this environment.
source /usr/local/Ascend/ascend-toolkit/set_env.sh
source /workspace/t5qkv-dev-20261029/env/venv/bin/activate
export PIP_CACHE_DIR=/workspace/t5qkv-dev-20261029/env/pip-cache
export XDG_CACHE_HOME=/workspace/t5qkv-dev-20261029/env/cache
export TORCH_EXTENSIONS_DIR=/workspace/t5qkv-dev-20261029/env/torch_extensions
export TMPDIR=/workspace/t5qkv-dev-20261029/env/tmp
