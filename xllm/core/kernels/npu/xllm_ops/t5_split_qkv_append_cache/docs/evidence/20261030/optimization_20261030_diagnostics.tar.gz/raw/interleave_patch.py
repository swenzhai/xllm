from pathlib import Path
p=Path("/workspace/t5qkv-dev-20261029/project/op_kernel/t5_split_qkv_append_cache_kernel.h")
s=p.read_text().replace("uint64_t{168}","uint64_t{176}")
s=s.replace("const CopyTask task = decode_task(tiling_, task_id);", "const CopyTask task = decode_task(tiling_, (task_id & 1) * tiling_.cache_tasks_per_tensor + task_id / 2);", 2)
p.write_text(s)
