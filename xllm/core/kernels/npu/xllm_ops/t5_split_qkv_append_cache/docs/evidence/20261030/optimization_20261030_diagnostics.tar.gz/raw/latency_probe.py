import importlib.util,sys,json,time,statistics
from pathlib import Path
import torch,torch_npu
p=Path('/workspace/t5qkv-dev-20261029')
sys.path.insert(0,str(p/'public'));sys.path.insert(0,str(p/'project'))
import solution,generate_data,verify,benchmark
cases=json.load(open(p/'public/case.json'))
torch.npu.set_device(0)
for i in [1,6,7]:
 c=cases[i];x=verify.device_inputs(c,generate_data.generate(c),'npu:0');a={v['name']:v['value'] for v in c['attr_desc']}
 for kind in ['run','run_direct','allocate','validate']:
  if kind=='allocate':
   fn=lambda:tuple(torch.empty(d['shape'],dtype=x[0].dtype,device=x[0].device) for d in c['output_desc'])
  elif kind=='validate': fn=lambda:solution.prepare(x,a)
  else: fn=lambda:getattr(solution,kind)(x,a)
  print(json.dumps({'case':c['case_name'],'kind':kind,'result':benchmark.measure(fn,torch.npu)}),flush=True)
