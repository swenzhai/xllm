# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
import sys
from pathlib import Path
import torch
import torch_npu
root = Path('/workspace/t5qkv-dev-20261029')
sys.path[:0] = [str(root/'public'), str(root/'project')]
import generate_data, verify, solution
import json
case = json.loads((root/'public/case.json').read_text())[7]
arrays = generate_data.generate(case)
attrs = {a['name']:a['value'] for a in case['attr_desc']}
inputs = verify.device_inputs(case, arrays, 'npu:0')
for _ in range(8):
    output = solution.run(inputs, attrs)
    torch.npu.synchronize()
    del output
print('profile completed')
