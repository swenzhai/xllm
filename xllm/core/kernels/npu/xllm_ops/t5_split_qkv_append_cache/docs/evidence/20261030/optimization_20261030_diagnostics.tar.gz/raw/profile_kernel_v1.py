import sys, json
from pathlib import Path
import torch, torch_npu
p=Path('/workspace/t5qkv-dev-20261029')
sys.path.insert(0,str(p/'project'))
import solution
cases=json.load(open(p/'public/case.json'))
torch.npu.set_device(0)
for index in [1,7]:
    case=cases[index]
    inputs=[torch.empty(d['shape'],dtype=torch.float16,device='npu:0') for d in case['input_desc']]
    attrs={d['name']:d['value'] for d in case['attr_desc']}
    torch.npu.synchronize()
    for entry in ['run','run_direct']:
        print(json.dumps({'case':case['case_name'],'entry':entry,'calls':4}),flush=True)
        for _ in range(4):
            result=getattr(solution,entry)(inputs,attrs)
            torch.npu.synchronize()
print('profile workload complete',flush=True)
