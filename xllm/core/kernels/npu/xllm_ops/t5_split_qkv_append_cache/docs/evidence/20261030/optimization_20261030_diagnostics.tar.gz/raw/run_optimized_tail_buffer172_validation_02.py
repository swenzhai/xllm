# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Execute actual validation commands; preserve each child's original output."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/t5qkv-dev-20261029')
PROJECT = ROOT / 'project'
REPORTS = ROOT / 'reports/optimized_tail_buffer172_final_02'
INSTALL = ROOT / 'install_tail_buffer172_01/vendors/t5qkv'


def snapshot() -> dict[str, str]:
    files = []
    for p in PROJECT.rglob('*'):
        relative = p.relative_to(PROJECT)
        if any(part.startswith('build') or part == '__pycache__' for part in relative.parts[:-1]):
            continue
        if p.is_file():
            files.append(p)
    files += list((ROOT/'public').glob('*'))
    files += [PROJECT/'build_direct/libt5qkv_direct.so']
    files += [p for p in INSTALL.rglob('*') if p.is_file()]
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(files)) if p.is_file()}


def main() -> None:
    REPORTS.mkdir(exist_ok=False)
    before = snapshot()
    (REPORTS/'pretest_manifest.json').write_text(json.dumps(before, indent=2))
    commands = [
        ('public_accuracy', [sys.executable, 'verify.py', '--solution-file', str(PROJECT/'solution.py'), '--report', str(REPORTS/'public_accuracy.json')], ROOT/'public'),
        ('extended', [sys.executable, str(PROJECT/'tests/acceptance.py'), '--package-dir', str(ROOT/'public'), '--solution-file', str(PROJECT/'solution.py'), '--report', str(REPORTS/'extended.json')], PROJECT),
        ('queue_stress', [sys.executable, str(PROJECT/'tests/queue_stress.py'), '--package-dir', str(ROOT/'public'), '--solution-file', str(PROJECT/'solution.py'), '--report', str(REPORTS/'queue_stress.json')], PROJECT),
        ('cache_boundary', [sys.executable, str(PROJECT/'tests/cache_boundary.py'), '--solution-file', str(PROJECT/'solution.py'), '--report', str(REPORTS/'cache_boundary.json')], PROJECT),
        ('host_mapping', [sys.executable, str(PROJECT/'tests/check_task_mapping.py')], PROJECT),
        ('performance', [sys.executable, 'benchmark.py', '--solution-file', str(PROJECT/'solution.py'), '--report', str(REPORTS/'performance.json')], ROOT/'public'),
        ('same_device', [sys.executable, str(PROJECT/'tests/compare_same_device.py'), '--package-dir', str(ROOT/'public'), '--solution-file', str(PROJECT/'solution.py'), '--report', str(REPORTS/'same_device.json')], PROJECT),
        ('performance_confirm', [sys.executable, 'benchmark.py', '--solution-file', str(PROJECT/'solution.py'), '--report', str(REPORTS/'performance_confirm.json')], ROOT/'public'),
        ('same_device_confirm', [sys.executable, str(PROJECT/'tests/compare_same_device.py'), '--package-dir', str(ROOT/'public'), '--solution-file', str(PROJECT/'solution.py'), '--report', str(REPORTS/'same_device_confirm.json')], PROJECT),
    ]
    records = []
    for name, command, cwd in commands:
        start = time.time()
        with (REPORTS/(name+'.log')).open('wb') as log:
            result = subprocess.run(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
        record = {'name': name, 'command': command, 'cwd': str(cwd), 'exit_code': result.returncode, 'elapsed_seconds': time.time()-start}
        records.append(record)
        (REPORTS/'execution_index.json').write_text(json.dumps(records, indent=2))
        print(json.dumps(record), flush=True)
        if result.returncode != 0:
            raise RuntimeError(name+' failed; original evidence preserved')
    after = snapshot()
    (REPORTS/'posttest_manifest.json').write_text(json.dumps(after, indent=2))
    assert before == after, 'Source or loaded artifact changed during validation'
    targets = json.loads((ROOT/'public/performance_targets.json').read_text())
    limits = {c['case_name']: c['max_wall_us'] for c in targets['cases']}
    for name in ['same_device','same_device_confirm']:
        report = json.loads((REPORTS/(name+'.json')).read_text())
        assert len(report['cases']) == 10
        for case in report['cases']:
            assert case['results']['custom']['wall_us_median'] <= limits[case['case_name']], case['case_name']
    print('OPTIMIZED_VALIDATION_PASSED official_accuracy=35 extended=206 performance=10x4_batches source_and_artifacts_unchanged', flush=True)


if __name__ == '__main__':
    main()
