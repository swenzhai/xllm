# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Record actual loaded libraries after a real operator invocation."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
root=Path('/workspace/t5qkv-dev-20261029')
sys.path[:0]=[str(root/'public'),str(root/'project')]
import torch
import torch_npu
import generate_data
import golden
import solution
import verify
case=json.loads((root/'public/case.json').read_text())[1]
arrays=generate_data.generate(case)
attrs={a['name']:a['value'] for a in case['attr_desc']}
inputs=verify.device_inputs(case,arrays,'npu:0')
outputs=solution.run(inputs,attrs)
torch.npu.synchronize()
accuracy=verify.compare(case,arrays,outputs,golden.calculate(arrays,attrs))
files={}
for line in Path('/proc/self/maps').read_text().splitlines():
    path=line.split()[-1]
    if path.startswith('/') and any(s in path for s in ['_t5qkv','libt5qkv_direct','libcust_']):
        p=Path(path)
        if p.is_file():files[str(p.resolve())]=hashlib.sha256(p.read_bytes()).hexdigest()
expected=Path(os.environ['T5QKV_OPAPI_LIB']).resolve()
assert str(expected) in files
smi=subprocess.run(['npu-smi','info'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
(root/'reports/environment_tail172_npu_smi.log').write_bytes(smi.stdout)
data={'npu_executed':True,'device_index':0,'visible_device_count':torch.npu.device_count(),
      'device_name':torch.npu.get_device_name(0),'python':platform.python_version(),
      'torch':str(torch.__version__),'torch_npu':str(torch_npu.__version__),
      'os_release':Path('/etc/os-release').read_text(),'platform':platform.platform(),
      'environment':{k:os.environ.get(k) for k in ['ASCEND_RT_VISIBLE_DEVICES','ASCEND_CUSTOM_OPP_PATH','T5QKV_OPAPI_LIB','TASK_QUEUE_ENABLE','PYTORCH_NPU_ALLOC_CONF','ASCEND_LAUNCH_BLOCKING']},
      'loaded_artifacts_sha256':files,'accuracy':accuracy}
text=json.dumps(data,indent=2)
(root/'reports/runtime_identity_tail172.json').write_text(text)
print(text)
