# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Supplementary same-device measurement using the unmodified public timer."""
import hashlib
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

ROOT = Path('/workspace/t5qkv-dev-20261029')
sys.path.insert(0, str(ROOT / 'public'))
import benchmark
import generate_data
import golden
import verify
import numpy as np
import torch
import torch_npu


def candidates(inputs, attrs):
    (qkv, pk, pv) = inputs
    (b, h, l, d) = pk.shape

    def views_and_concatenation():
        parts = qkv.reshape(b, 3, h, d)
        q = parts[:, 0].reshape(b, h, 1, d).clone(memory_format=torch.contiguous_format)
        k = parts[:, 1].reshape(b, h, 1, d)
        v = parts[:, 2].reshape(b, h, 1, d)
        return (q, torch.cat((pk, k), dim=2), torch.cat((pv, v), dim=2))
    return {'views_concat_q_copy': views_and_concatenation}


def main() -> None:
    output = Path(sys.argv[1])
    output.mkdir(parents=True, exist_ok=False)
    torch.npu.set_device(0)
    solution = benchmark.load_module('submitted_solution', ROOT / 'project/solution.py')
    report = {'started_utc': datetime.now(timezone.utc).isoformat(), 'protocol': benchmark.PROTOCOL,
              'environment': benchmark.environment_info(torch, torch_npu, 0), 'cases': [],
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'status': 'running', 'npu_executed': True}
    for case in json.loads((ROOT / 'public/case.json').read_text()):
        if not case.get('performance'):
            continue
        arrays = generate_data.generate(case)
        attrs = {a['name']: a['value'] for a in case['attr_desc']}
        expected = golden.calculate(arrays, attrs)
        inputs = verify.device_inputs(case, arrays, 'npu:0')
        functions = {'custom': lambda: solution.run(inputs, attrs), **candidates(inputs, attrs)}
        accuracy = {}
        for name, fn in functions.items():
            outputs = tuple(fn())
            torch.npu.synchronize()
            verify.validate_ownership(inputs, outputs)
            accuracy[name] = verify.compare(case, arrays, outputs, expected)
            for tensor, original in zip(inputs, arrays):
                assert np.array_equal(verify.cpu_array(tensor).view(np.uint16), original.view(np.uint16))
            del outputs
        results = {name: benchmark.measure(fn, torch.npu) for name, fn in functions.items()}
        ratio = results['custom']['wall_us_median'] / results['views_concat_q_copy']['wall_us_median']
        record = {'case_name': case['case_name'], 'accuracy': accuracy, 'results': results,
                  'selected_baseline': 'views_concat_q_copy', 'excluded_candidates': [], 'ratio': ratio}
        report['cases'].append(record)
        (output / 'same_device_baseline.json').write_text(json.dumps(report, indent=2))
        print(json.dumps(record, allow_nan=False), flush=True)
        del inputs, functions
    report['status'] = 'measured'
    report['finished_utc'] = datetime.now(timezone.utc).isoformat()
    (output / 'same_device_baseline.json').write_text(json.dumps(report, indent=2))
    print('SAME_DEVICE_BASELINE_MEASURED cases=10 accuracy=both_entries_verified protocol=50/200/5', flush=True)


if __name__ == '__main__':
    main()
