from pathlib import Path
root=Path("/workspace/t5qkv-dev-20261029")
p=root/"project/op_kernel/t5_split_qkv_append_cache_kernel.h"
s=(root/"reports/pipeline176_kernel.h").read_text()
s=s.replace("process_history(history_tasks);", "process_history(0, tiling_.cache_tasks_per_tensor);\n    process_history(tiling_.cache_tasks_per_tensor, tiling_.cache_tasks_per_tensor);")
s=s.replace("process_history(uint32_t count)", "process_history(uint32_t first, uint32_t count)")
s=s.replace("partition_tasks(0, count,", "partition_tasks(first, count,")
p.write_text(s)
