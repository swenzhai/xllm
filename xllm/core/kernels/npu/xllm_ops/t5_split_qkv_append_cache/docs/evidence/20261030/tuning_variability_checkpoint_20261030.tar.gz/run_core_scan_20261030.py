# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Run the unchanged public timer under diagnostic-only core-count overrides."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/t5qkv-dev-20261029')
REPORT = ROOT / 'reports/core_scan_20261030_01'
PROJECT = ROOT / 'project'
INSTALL = ROOT / 'install_core_scan_01/vendors/t5qkv'


def _snapshot() -> dict[str, str]:
    files = [p for p in (ROOT / 'project_core_scan_01').rglob('*')
             if p.is_file() and not any(x.startswith('build') or x in ['__pycache__','evidence']
                                      for x in p.relative_to(ROOT / 'project_core_scan_01').parts[:-1])]
    files += [p for p in INSTALL.rglob('*') if p.is_file()]
    files += [p for p in (ROOT/'public').iterdir() if p.is_file()]
    files += [p for p in PROJECT.glob('*.so')]
    files += [PROJECT/'solution.py', PROJECT/'build_direct/libt5qkv_direct.so']
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}


def _main() -> None:
    REPORT.mkdir(exist_ok=False)
    before = _snapshot()
    (REPORT/'pretest_manifest.json').write_text(json.dumps(before,indent=2))
    records = []
    for cores in [48,40,32,24,16,12,8]:
        env = dict(os.environ, T5QKV_DIAG_VECTOR_CORES=str(cores),
                   ASCEND_RT_VISIBLE_DEVICES='0', ASCEND_CUSTOM_OPP_PATH=str(INSTALL),
                   T5QKV_OPAPI_LIB=str(INSTALL/'op_api/lib/libcust_opapi.so'))
        env.pop('PYTORCH_NPU_ALLOC_CONF',None)
        output = REPORT/f'cores_{cores}.json'
        command = [sys.executable,str(ROOT/'public/benchmark.py'),'--solution-file',
                   str(PROJECT/'solution.py'),'--report',str(output)]
        with output.with_suffix('.log').open('wb') as log:
            child = subprocess.run(command,cwd=ROOT/'public',env=env,stdout=log,stderr=subprocess.STDOUT)
        result = json.loads(output.read_text())
        assert result.get('npu_executed') and not result.get('error')
        assert len(result['cases'])==10
        row = {'scope':'diagnostic_only_not_acceptance','cores':cores,'exit_code':child.returncode,
               'status':result['status'],'command':command,'results':[
                   {'case_name':c['case_name'],'wall_us_median':c['results']['custom']['wall_us_median']}
                   for c in result['cases']]}
        records.append(row)
        (REPORT/'DERIVED_SCAN_SUMMARY.json').write_text(json.dumps(records,indent=2))
        print(json.dumps(row),flush=True)
    after=_snapshot()
    (REPORT/'posttest_manifest.json').write_text(json.dumps(after,indent=2))
    assert before==after,'Source or artifacts changed during the scan'


if __name__=='__main__':
    _main()
