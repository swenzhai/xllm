# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Keep every unchanged-timer result; confirm a selected diagnostic twice."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/workspace/t5qkv-dev-20261029')
REPORT=ROOT/'reports/row192_confirm_20261030_01'
INSTALL=ROOT/'install_row_scan_01/vendors/t5qkv'
RECORDS=[]


def _snapshot() -> dict[str,str]:
    project=ROOT/'project_row_scan_01'
    files=[p for p in project.rglob('*') if p.is_file() and
           not any(x.startswith('build') or x=='__pycache__' for x in p.relative_to(project).parts[:-1])]
    files += [p for p in INSTALL.rglob('*') if p.is_file()]
    files += [p for p in (ROOT/'public').iterdir() if p.is_file()]
    files += [p for p in (ROOT/'project').glob('*.so')]
    files += [ROOT/'project/solution.py',ROOT/'project/build_direct/libt5qkv_direct.so']
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}


def _run(tile:int,budget:int,stage:str,rows:int) -> dict:
    name=f'{len(RECORDS):02}_{stage}_tile{tile}_rows{rows}'
    output=REPORT/(name+'.json')
    env=dict(os.environ,ASCEND_RT_VISIBLE_DEVICES='0',ASCEND_CUSTOM_OPP_PATH=str(INSTALL),
             T5QKV_OPAPI_LIB=str(INSTALL/'op_api/lib/libcust_opapi.so'),
             T5QKV_DIAG_TILE_ELEMENTS=str(tile),T5QKV_DIAG_CACHE_MIB=str(budget),T5QKV_DIAG_CACHE_ROWS=str(rows))
    env.pop('PYTORCH_NPU_ALLOC_CONF',None)
    command=[sys.executable,str(ROOT/'public/benchmark.py'),'--solution-file',
             str(ROOT/'project/solution.py'),'--report',str(output)]
    with output.with_suffix('.log').open('wb') as log:
        child=subprocess.run(command,cwd=ROOT/'public',env=env,stdout=log,stderr=subprocess.STDOUT)
    result=json.loads(output.read_text())
    assert result.get('npu_executed') and not result.get('error'),name
    assert len(result['cases'])==10
    limits={c['case_name']:c['max_wall_us'] for c in json.loads((ROOT/'public/performance_targets.json').read_text())['cases']}
    timings=[{'case_name':c['case_name'],'wall_us_median':c['results']['custom']['wall_us_median']} for c in result['cases']]
    row={'scope':'diagnostic_only_not_acceptance','name':name,'stage':stage,'tile_elements':tile,
         'cache_budget_mib':budget,'cache_rows':rows,'exit_code':child.returncode,'status':result['status'],
         'max_normalized_latency':max(c['wall_us_median']/limits[c['case_name']] for c in timings),
         'command':command,'results':timings}
    RECORDS.append(row)
    (REPORT/'DERIVED_SCAN_SUMMARY.json').write_text(json.dumps(RECORDS,indent=2))
    print(json.dumps(row),flush=True)
    return row


def _main() -> None:
    REPORT.mkdir(exist_ok=False)
    before=_snapshot();(REPORT/'pretest_manifest.json').write_text(json.dumps(before,indent=2))
    for _ in range(3):
        _run(47104,176,'row192_confirm',192)
    after=_snapshot();(REPORT/'posttest_manifest.json').write_text(json.dumps(after,indent=2))
    assert before==after,'Source or binary changed during parameter scan'


if __name__=='__main__':
    _main()
