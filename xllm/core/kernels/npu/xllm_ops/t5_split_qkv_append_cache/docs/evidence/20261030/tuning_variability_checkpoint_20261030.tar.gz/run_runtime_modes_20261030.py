# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Controlled process-local runtime diagnostics using the unmodified timer."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/workspace/t5qkv-dev-20261029')
REPORT=ROOT/'reports/runtime_modes_20261030_01'
INSTALL=ROOT/'install_balanced_tile_01/vendors/t5qkv'


def _main() -> None:
    REPORT.mkdir(exist_ok=False)
    spec=importlib.util.spec_from_file_location('snapshot_driver',ROOT/'run_optimized_balanced_tile_validation.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    before=module.snapshot();(REPORT/'pretest_manifest.json').write_text(json.dumps(before,indent=2))
    records=[]
    for name,queue,allocator in [('queue0_native','0',None),('queue2_expand','2','expandable_segments:True')]:
        env=dict(os.environ,ASCEND_RT_VISIBLE_DEVICES='0',ASCEND_CUSTOM_OPP_PATH=str(INSTALL),
                 T5QKV_OPAPI_LIB=str(INSTALL/'op_api/lib/libcust_opapi.so'),TASK_QUEUE_ENABLE=queue)
        if allocator is None:env.pop('PYTORCH_NPU_ALLOC_CONF',None)
        else:env['PYTORCH_NPU_ALLOC_CONF']=allocator
        for index in range(3):
            output=REPORT/f'{name}_{index:02}.json'
            command=[sys.executable,str(ROOT/'public/benchmark.py'),'--solution-file',
                     str(ROOT/'project/solution.py'),'--report',str(output)]
            with output.with_suffix('.log').open('wb') as log:
                child=subprocess.run(command,cwd=ROOT/'public',env=env,stdout=log,stderr=subprocess.STDOUT)
            result=json.loads(output.read_text())
            assert result.get('npu_executed') and not result.get('error')
            row={'scope':'process_runtime_diagnostic_not_acceptance','mode':name,'index':index,
                 'runtime_options':{key:env.get(key) for key in ['ASCEND_RT_VISIBLE_DEVICES','TASK_QUEUE_ENABLE','PYTORCH_NPU_ALLOC_CONF']},
                 'command':command,'exit_code':child.returncode,'status':result['status'],
                 'results':[{'case_name':c['case_name'],'wall_us_median':c['results']['custom']['wall_us_median']} for c in result['cases']]}
            records.append(row);(REPORT/'DERIVED_MODE_SUMMARY.json').write_text(json.dumps(records,indent=2))
            print(json.dumps(row),flush=True)
    after=module.snapshot();(REPORT/'posttest_manifest.json').write_text(json.dumps(after,indent=2))
    assert before==after


if __name__=='__main__':
    _main()
