# Copyright 2026 The xLLM Authors. Licensed under the Apache License, Version 2.0.
"""Diagnostic workload for hardware counters; never an acceptance timer."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/workspace/t5qkv-dev-20261029')
sys.path[:0] = [str(ROOT / 'public'), str(ROOT / 'project')]
import torch
import torch_npu  # noqa: F401
import generate_data
import verify
import solution

torch.npu.set_device(0)
cases = json.loads((ROOT / 'public/case.json').read_text())
for index in (7, 17):
    case = cases[index]
    assert f'_{index:03}_' in case['case_name']
    arrays = generate_data.generate(case)
    attrs = {a['name']: a['value'] for a in case['attr_desc']}
    inputs = verify.device_inputs(case, arrays, 'npu:0')
    torch.npu.synchronize()
    print(json.dumps({'scope': 'diagnostic_hardware_counters_only',
                      'case_name': case['case_name'], 'calls': 80,
                      'warmup_calls': 64, 'retained_tail_calls': 16}), flush=True)
    for _ in range(80):
        output = solution.run(inputs, attrs)
        torch.npu.synchronize()
        del output
    del inputs, arrays
print(json.dumps({'scope': 'diagnostic_hardware_counters_only', 'completed': True,
                  'kernel_sha256': hashlib.sha256((ROOT / 'project/op_kernel/t5_split_qkv_append_cache_kernel.h').read_bytes()).hexdigest()}), flush=True)
